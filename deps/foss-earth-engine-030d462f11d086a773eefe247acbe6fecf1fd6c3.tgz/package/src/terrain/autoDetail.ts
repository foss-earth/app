/** How the automatic adjustment observes frames and moves: `map.auto.*`. */
export interface AutoDetailTuning {
  /** The frame interval aimed for, ms; null measures the display's. */
  goalMs: number | null;
  /** The shortest goal, ms: a frame-rate cap's interval, 0 without one. Capped frames are not slow ones. */
  leastGoalMs?: number;
  /** Multiples of the goal: a slower window counts toward coarsening, a faster one toward refining. */
  coarsenAbove: number;
  refineBelow: number;
  windowMs: number;
  coarsenWindows: number;
  refineWindows: number;
  /** Levels per adjustment. */
  step: number;
  /** The least time between adjustments, ms. */
  intervalMs: number;
}

export interface AutoDetailDecision {
  at: number;
  /** Omitted by older hosts for a frame-time decision. */
  reason?: "frame-time" | "settings";
  /** Levels coarser than requested, before and after. */
  from: number;
  to: number;
  meanFrameMs: number;
  goalMs: number;
}

export interface AutoDetailState {
  /** Levels coarser than requested: 0 is the request itself. */
  adjustment: number;
  /** The most it may coarsen: the room left in the enabled details' ranges. */
  room: number;
  /** The goal in use, ms: set, or measured; null until a frame is measured. */
  goalMs: number | null;
  /** The last window's average frame interval, ms. */
  lastMeanMs: number | null;
  lastDecision: AutoDetailDecision | null;
}

/**
 * One adjustment, in levels, shared by every detail allowed to move: each
 * turns it into its own scale and stops at its own range. It only ever
 * coarsens from what was requested, and returns toward it; it never refines
 * past it. Frame intervals over 250 ms, and frames while suspended (a hidden
 * page), are not evidence of load.
 */
export function createAutoDetailController(initial: AutoDetailTuning) {
  let tuning = initial;
  let adjustment = 0;
  let room = 0;
  let measuredGoal: number | null = null;
  let windowStartedAt: number | null = null;
  let total = 0;
  let frames = 0;
  const intervals: number[] = [];
  let slow = 0;
  let fast = 0;
  let nextChangeAt = 0;
  let lastMeanMs: number | null = null;
  let lastDecision: AutoDetailDecision | null = null;

  const restartWindow = (): void => { windowStartedAt = null; total = 0; frames = 0; intervals.length = 0; };
  const resetObservation = (): void => { restartWindow(); slow = 0; fast = 0; };
  const goal = (): number | null => {
    const aimed = tuning.goalMs ?? measuredGoal;
    return aimed === null ? null : Math.max(aimed, tuning.leastGoalMs ?? 0);
  };

  function decide(now: number, to: number, mean: number, goalMs: number): AutoDetailDecision {
    lastDecision = { at: now, reason: "frame-time", from: adjustment, to, meanFrameMs: mean, goalMs };
    adjustment = to;
    slow = 0;
    fast = 0;
    nextChangeAt = now + tuning.intervalMs;
    return lastDecision;
  }

  return {
    getState: (): AutoDetailState => ({ adjustment, room, goalMs: goal(), lastMeanMs, lastDecision }),
    getAdjustment: () => adjustment,
    setTuning(next: AutoDetailTuning): void {
      if (next.windowMs !== tuning.windowMs || next.goalMs !== tuning.goalMs || next.leastGoalMs !== tuning.leastGoalMs) resetObservation();
      tuning = next;
    },
    /**
     * How far the enabled details can still coarsen, in levels. Less room than
     * the current adjustment pulls it back at once; none stops adjusting.
     */
    setRoom(next: number): AutoDetailDecision | null {
      room = Math.max(0, next);
      if (room === 0) { resetObservation(); nextChangeAt = 0; }
      if (adjustment <= room) return null;
      const decision: AutoDetailDecision = { at: lastDecision?.at ?? 0, reason: "settings", from: adjustment, to: room, meanFrameMs: lastMeanMs ?? 0, goalMs: goal() ?? 0 };
      adjustment = room;
      lastDecision = decision;
      return decision;
    },
    /** Returns a decision when the adjustment changed. */
    observe(now: number, frameMs: number, suspended: boolean): AutoDetailDecision | null {
      if (suspended || !Number.isFinite(frameMs) || frameMs <= 0 || frameMs > 250) {
        resetObservation();
        return null;
      }
      if (windowStartedAt === null) windowStartedAt = now;
      total += frameMs;
      frames += 1;
      if (frameMs >= 2) intervals.push(frameMs);
      if (now - windowStartedAt < tuning.windowMs) return null;
      const mean = total / frames;
      // A short scheduling interval is not a new display refresh rate. Use
      // the median of a complete observation window before lowering the goal.
      // Slower windows still cannot move the goal to match an overloaded app.
      if (intervals.length > 0) {
        intervals.sort((a, b) => a - b);
        const median = intervals[Math.floor(intervals.length / 2)];
        measuredGoal = measuredGoal === null ? median : Math.min(measuredGoal, median);
      }
      restartWindow();
      lastMeanMs = mean;
      const goalMs = goal();
      if (goalMs === null || (room <= 0 && adjustment === 0)) return null;
      if (mean > goalMs * tuning.coarsenAbove) {
        slow += 1;
        fast = 0;
        if (slow >= tuning.coarsenWindows && now >= nextChangeAt && adjustment < room) {
          return decide(now, Math.min(room, adjustment + tuning.step), mean, goalMs);
        }
      } else if (mean < goalMs * tuning.refineBelow) {
        fast += 1;
        slow = 0;
        if (fast >= tuning.refineWindows && now >= nextChangeAt && adjustment > 0) {
          return decide(now, Math.max(0, adjustment - tuning.step), mean, goalMs);
        }
      } else {
        slow = 0;
        fast = 0;
      }
      return null;
    },
  };
}

export type AutoDetailController = ReturnType<typeof createAutoDetailController>;
