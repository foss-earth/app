import type { LocationSearchResult, LocationSearchProvider } from "../contracts.js";
import type { Airport } from "./airportTypes.js";
import type { AirportLookupProvider } from "./searchAirports.js";
import type { LocationLookupCache } from "./lookupCache.js";
import type { LocationLookupTransport } from "./transport.js";
export interface LocationSearchPorts { cache: LocationLookupCache; transport: LocationLookupTransport; airports: AirportLookupProvider;
  queryContribution?(text: string): { query: string; contribution?: unknown };
  airportContribution?(data: { summary?: AirportSummary; airport?: Airport; contribution?: unknown }): unknown;
}

interface Place {
  place_id: number; osm_type?: string; osm_id?: number;
  display_name: string; name?: string; lat: string; lon: string;
  type?: string; addresstype?: string;
  address?: Record<string, string>;
  extratags?: Record<string, string>;
}
export interface AirportSummary {
  code: string; iata?: string; icao?: string; name: string; latitude: number; longitude: number;
  type?: string; distance_km?: number;
  municipality?: string; region_name?: string; country_name?: string;
}
export interface NearbyCity { name: string; state?: string; country?: string }
/** The public geocoder's usage policy: at most one request a second. */
const GEOCODER_INTERVAL_MS = 1100;
export function createLocationSearch(ports: LocationSearchPorts) {
const { cachedLookup } = ports.cache;
let geocoderQueue: Promise<unknown> = Promise.resolve();
let lastGeocoderRequest = -Infinity;
const json = (url: string, signal: AbortSignal) => ports.transport.json(url, signal, "Location");
const record = (value: unknown): value is Record<string, unknown> => typeof value === "object" && value !== null;
const optionalString = (value: unknown) => value === undefined || value === null || typeof value === "string";
const optionalStrings = (value: unknown) => value === undefined || value === null || (record(value) && Object.values(value).every(optionalString));
function validPlaces(value: unknown): value is Place[] {
  return Array.isArray(value) && value.every(place => record(place) && typeof place.place_id === "number"
    && typeof place.display_name === "string" && typeof place.lat === "string" && typeof place.lon === "string"
    && optionalString(place.name) && optionalStrings(place.address) && optionalStrings(place.extratags));
}
function validNearby(value: unknown): value is { data: AirportSummary[] } {
  return record(value) && Array.isArray(value.data) && value.data.every(airport => record(airport)
    && typeof airport.code === "string" && typeof airport.name === "string"
    && typeof airport.latitude === "number" && typeof airport.longitude === "number"
    && [airport.iata, airport.icao, airport.type, airport.municipality, airport.region_name, airport.country_name].every(optionalString));
}

async function geocode(params: Record<string, string>, signal: AbortSignal): Promise<Place[]> {
  const url = new URL("https://nominatim.openstreetmap.org/search");
  for (const [key, value] of Object.entries({ format: "jsonv2", limit: "6", addressdetails: "1", extratags: "1", ...params })) url.searchParams.set(key, value);
  const cacheUrl = new URL(url);
  for (const [key, value] of Object.entries(params)) cacheUrl.searchParams.set(key, value.trim().replace(/\s+/g, " ").toLowerCase());
  // Cache hits bypass the network queue; the public geocoder permits one request/second.
  return cachedLookup(cacheUrl.href, signal, validPlaces, lookupSignal => {
    const request = geocoderQueue.catch(() => {}).then(async () => {
      lookupSignal.throwIfAborted();
      const delay = Math.max(0, lastGeocoderRequest + GEOCODER_INTERVAL_MS - ports.transport.nowMs());
      if (delay) await ports.transport.wait(delay, lookupSignal);
      lookupSignal.throwIfAborted();
      lastGeocoderRequest = ports.transport.nowMs();
      const result = await json(url.href, lookupSignal);
      if (!validPlaces(result)) throw new Error("Invalid location search response.");
      return result;
    });
    geocoderQueue = request;
    return request;
  });
}
const isCity = (place: Place) => ["city", "town", "village", "municipality"].includes(place.addresstype ?? place.type ?? "");
const validCoordinates = (lat: number, lon: number) => Number.isFinite(lat) && Number.isFinite(lon) && Math.abs(lat) <= 90 && Math.abs(lon) <= 180;

const normalizeName = (name: string) => name.trim().normalize("NFKD").replace(/\p{M}/gu, "").toLowerCase();

function airportResult(airport: AirportSummary, contribution?: unknown, city?: NearbyCity): LocationSearchResult<AbortSignal> {
  const location = [...new Set([airport.municipality, airport.region_name, airport.country_name]
    .filter((value): value is string => typeof value === "string" && value.trim().length > 0)
    .map(value => value.trim()))].join(", ");
  const distance = typeof airport.distance_km === "number" && Number.isFinite(airport.distance_km) && airport.distance_km >= 0
    ? `${Math.round(airport.distance_km)} km ${city ? `from ${city.name}` : "away"}` : "";
  const inCity = city && airport.municipality && normalizeName(airport.municipality) === normalizeName(city.name)
    && (!city.state || !airport.region_name || normalizeName(city.state) === normalizeName(airport.region_name))
    && (!city.country || !airport.country_name || normalizeName(city.country) === normalizeName(airport.country_name));
  const subtitle = inCity ? "" : [location, distance].filter(Boolean).join(" · ");
  return {
    id: `airport:${airport.code}`, kind: "airport", label: `${airport.iata ?? airport.code} · ${airport.name}`,
    latDeg: airport.latitude, lonDeg: airport.longitude, hostData: ports.airportContribution?.({ summary: airport, contribution }), subtitle: subtitle || undefined,
    resolve: async signal => {
      const { searchAirports } = ports.airports;
      const lookupCode = airport.icao ?? airport.iata ?? airport.code;
      const matches = await searchAirports(lookupCode, signal);
      signal.throwIfAborted();
      const full = matches.find(item => item.code === airport.code) ?? matches[0];
      if (!full) throw new Error("Runway details are unavailable for this airport.");
      return { id: `airport:${full.code}`, kind: "airport", label: `${full.code} · ${full.name}`,
        latDeg: full.latDeg, lonDeg: full.lonDeg, hostData: ports.airportContribution?.({ airport: full, contribution }), subtitle: subtitle || undefined };
    },
  };
}

async function nearbyAirports(latDeg: number, lonDeg: number, signal: AbortSignal, city?: NearbyCity, contribution?: unknown): Promise<readonly LocationSearchResult<AbortSignal>[]> {
  if (!validCoordinates(latDeg, lonDeg)) throw new Error("Invalid city coordinates.");
  const url = new URL("https://api.freeairportdb.com/v1/airports/nearby");
  for (const [key, value] of Object.entries({ lat: String(latDeg), lng: String(lonDeg), radius: "80", limit: "50" })) url.searchParams.set(key, value);
  const response = await cachedLookup(url.href, signal, validNearby, async lookupSignal => {
    const value = await json(url.href, lookupSignal);
    if (!validNearby(value)) throw new Error("Nearby airports are temporarily unavailable.");
    return value;
  });
  const rank = (type?: string) => type === "large_airport" ? 0 : type === "medium_airport" ? 1 : 2;
  const unique = new Map<string, AirportSummary>();
  for (const airport of response.data) {
    if (typeof airport.code !== "string" || !airport.name || !validCoordinates(airport.latitude, airport.longitude)) continue;
    if (!["large_airport", "medium_airport", "small_airport"].includes(airport.type ?? "")) continue;
    unique.set(airport.code, airport);
  }
  return [...unique.values()].sort((a, b) => rank(a.type) - rank(b.type) || (a.distance_km ?? Infinity) - (b.distance_km ?? Infinity))
    .slice(0, 12).map(airport => airportResult(airport, contribution, city));
}

function placeResult(place: Place, query: string, contribution?: unknown): LocationSearchResult<AbortSignal> | null {
  const latDeg = Number(place.lat), lonDeg = Number(place.lon);
  if (!validCoordinates(latDeg, lonDeg)) return null;
  if (place.type === "aerodrome" || place.addresstype === "aerodrome") {
    const code = place.extratags?.icao ?? place.extratags?.iata ?? (/^[a-z0-9]{3,4}$/i.test(query) ? query.toUpperCase() : undefined);
    if (code) return airportResult({ code, name: place.name ?? place.display_name, latitude: latDeg, longitude: lonDeg,
      municipality: place.address?.city ?? place.address?.town, region_name: place.address?.state, country_name: place.address?.country }, contribution);
  }
  const city = isCity(place);
  return { id: `${place.osm_type ?? "place"}:${place.osm_id ?? place.place_id}`, label: place.display_name,
    latDeg, lonDeg, kind: city ? "city" : "place",
    ...(city ? { childrenLabel: "Airports nearby", loadChildren: (signal: AbortSignal) => nearbyAirports(latDeg, lonDeg, signal, {
        name: place.address?.city ?? place.address?.town ?? place.address?.village ?? place.name ?? place.display_name.split(",")[0].trim(),
        state: place.address?.state, country: place.address?.country,
      }, contribution) } : {}),
  };
}

/** Resolve names/abbreviations on the API; there is no local city or alias dataset. */
const searchLocations: LocationSearchProvider<AbortSignal> = async (text, signal) => {
  const coordinates = text.trim().match(/^(-?\d+(?:\.\d+)?)\s*[,\s]\s*(-?\d+(?:\.\d+)?)$/);
  if (coordinates) {
    const latDeg = Number(coordinates[1]), lonDeg = Number(coordinates[2]);
    return validCoordinates(latDeg, lonDeg) ? [{ id: "coordinates", label: `${latDeg}, ${lonDeg}`, latDeg, lonDeg }] : [];
  }
  const { query, contribution } = ports.queryContribution?.(text) ?? { query: text.trim(), contribution: undefined };
  const places = await geocode({ q: query }, signal);
  const results = places.map(place => placeResult(place, query, contribution)).filter((r): r is LocationSearchResult<AbortSignal> => r !== null);
  const first = places[0];
  if (first && (first.type === "aerodrome" || first.addresstype === "aerodrome")) {
    const cityName = first.address?.city ?? first.address?.town;
    if (cityName) {
      try {
        const cities = await geocode({ city: cityName, state: first.address?.state ?? "", countrycodes: first.address?.country_code ?? "" }, signal);
        const city = cities.find(isCity);
        if (city) {
          const group = placeResult(city, query, contribution);
          if (group && !results.some(result => result.id === group.id)) results.unshift(group);
        }
      } catch { signal.throwIfAborted(); /* Keep the exact airport match if city enrichment fails. */ }
    }
  }
  if (!results.length && /^[a-z0-9]{3,4}$/i.test(query)) {
    const { searchAirports } = ports.airports;
    const airports = await searchAirports(query, signal);
    signal.throwIfAborted();
    return airports.map(airport => ({ id: `airport:${airport.code}`, label: `${airport.code} · ${airport.name}`,
      kind: "airport", latDeg: airport.latDeg, lonDeg: airport.lonDeg, hostData: ports.airportContribution?.({ airport, contribution }) }));
  }
  return results;
};

return { searchLocations, nearbyAirports };
}
