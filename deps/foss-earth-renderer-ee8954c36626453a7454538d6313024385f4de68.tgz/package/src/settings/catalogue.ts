import type { ParameterSpec } from "@foss-earth/ui/settings";
export { FRAME_PROFILING_IDS, frameProfilingParameters } from "./profiling.js";

export const RENDERER_TAB = "renderer";

export const RENDERER_PARAMETERS: readonly ParameterSpec[] = [
  {
    id: "renderer.backend",
    label: "Renderer",
    description: "The GPU interface that draws the globe. Auto-detect tries WebGPU and falls back to WebGL.",
    unit: "none",
    kind: "choice",
    choices: [
      { id: "auto", label: "Auto-detect" },
      { id: "webgpu", label: "WebGPU" },
      { id: "webgl2", label: "WebGL2" },
      { id: "webgl", label: "WebGL" },
    ],
    default: "auto",
    defaultReason: "WebGPU where it starts, otherwise the WebGL that last worked on this device.",
    home: { tab: RENDERER_TAB, section: "backend", level: "main" },
    appliesLive: false,
    source: "src/engine/babylon/createRendererMode.ts",
  },
  {
    id: "renderer.resolutionScale",
    label: "Resolution",
    description: "Pixels drawn per pixel of the display. Below 1 draws fewer and scales them up: softer, and less GPU work per frame.",
    unit: "ratio",
    kind: "number",
    bounds: () => ({ min: 0.25, max: 2 }),
    step: 0.25,
    scale: "log2",
    default: context => context.rendererDevicePixels === false
      ? { value: 1 / Math.max(1, context.devicePixelRatio), derivedFrom: "the safe WebGPU fallback, which draws a pixel per CSS pixel" }
      : { value: 1, derivedFrom: "a pixel drawn per pixel of the display" },
    defaultReason: "What the renderer drew before this became a parameter.",
    home: { tab: RENDERER_TAB, section: "frame", level: "main" },
    appliesLive: true,
    source: "src/engine/babylon/createBabylonRuntime.ts",
  },
  {
    id: "renderer.antialias",
    label: "Antialiasing",
    description: "Smooths the edges of the ground and models with several samples per pixel, where the renderer allows it. Off saves GPU memory and work.",
    unit: "none",
    kind: "boolean",
    default: true,
    defaultReason: "The renderer drew with it before this became a parameter; the safe WebGPU fallback turns it off.",
    home: { tab: RENDERER_TAB, section: "frame", level: "main" },
    appliesLive: false,
    source: "src/engine/babylon/createRendererMode.ts",
  },
  {
    id: "renderer.frameRateCap",
    label: "Frame rate cap",
    description: "The most frames drawn in a second. A lower cap saves power and heat; frames still come only when something changes.",
    unit: "fps",
    kind: "number",
    named: [{ id: "off", label: "Off" }],
    bounds: () => ({ min: 10, max: 240 }),
    step: 0.25,
    scale: "log2",
    default: "off",
    defaultReason: "No cap: as many frames as the display shows.",
    home: { tab: RENDERER_TAB, section: "frame", level: "main" },
    appliesLive: true,
    source: "src/engine/babylon/renderScheduler.ts",
  },
  {
    id: "renderer.clipping",
    label: "Depth range",
    description: "How the globe camera's nearest and farthest drawn distances are set: from its height each frame, or fixed. An app's own cameras, such as a cockpit's, keep theirs.",
    unit: "none",
    kind: "choice",
    choices: [
      { id: "automatic", label: "From the camera's height" },
      { id: "fixed", label: "Fixed" },
    ],
    default: "automatic",
    defaultReason: "Babylon's geospatial clipping keeps depth precise from the ground to orbit.",
    home: { tab: RENDERER_TAB, section: "clipping", level: "main" },
    appliesLive: true,
    source: "src/engine/babylon/createBabylonRuntime.ts",
  },
  {
    id: "renderer.clipping.fixed",
    label: "Fixed depth range",
    description: "The nearest and farthest distances drawn when the depth range is fixed. A wide range loses depth precision: far ground can flicker through near.",
    unit: "m",
    kind: "range",
    bounds: () => ({ min: 0.01, max: 1e9 }),
    step: 0.25,
    scale: "log2",
    default: { min: 1, max: 1e7 },
    defaultReason: "From a metre to past the far side of the Earth.",
    home: { tab: RENDERER_TAB, section: "clipping", level: "main" },
    appliesLive: true,
    source: "src/engine/babylon/createBabylonRuntime.ts",
  },
];

/**
 * Changes that should draw the same picture with less work, each off until
 * A/B checks and device trials confirm it (docs/validation/panorama-experiments.md;
 * candidate numbers from docs/webgl-panorama-performance-review.md). `all`
 * holds every other one on while it is on.
 */
export const RENDERER_EXPERIMENT_IDS = {
  all: "renderer.experiments.all",
  panoramaBookkeeping: "renderer.experiments.panoramaBookkeeping",
  opaqueImmersion: "renderer.experiments.opaqueImmersion",
  panoramaShaders: "renderer.experiments.panoramaShaders",
  presentationCandidates: "renderer.experiments.presentationCandidates",
} as const;

const EXPERIMENT_REASON = "Under A/B validation: meant to draw the same picture with less work, not yet confirmed on devices.";
const experimentHome = { tab: RENDERER_TAB, section: "experiments", level: "main" } as const;

export const RENDERER_EXPERIMENT_PARAMETERS: readonly ParameterSpec[] = [
  {
    id: RENDERER_EXPERIMENT_IDS.all,
    label: "All work-saving experiments",
    description: "Turns on every experiment in this section at once; each stays on while this is.",
    unit: "none",
    kind: "boolean",
    default: false,
    defaultReason: EXPERIMENT_REASON,
    home: experimentHome,
    appliesLive: true,
    source: "src/settings/appSettings.ts",
  },
  {
    id: RENDERER_EXPERIMENT_IDS.panoramaBookkeeping,
    label: "Panorama draws without test records",
    description: "Stops recording every panorama draw, its camera as text and earlier frames' uniforms, which only the renderer's own checks read; a check turns recording back on. Review candidate 5.",
    unit: "none",
    kind: "boolean",
    default: false,
    defaultReason: EXPERIMENT_REASON,
    home: experimentHome,
    appliesLive: true,
    source: "src/engine/babylon/panorama/panoramaRenderer.ts",
  },
  {
    id: RENDERER_EXPERIMENT_IDS.opaqueImmersion,
    label: "Opaque panorama",
    description: "Draws a panorama shown at full opacity without blending it over the frame behind, crossfades between two of its images included; fades from the globe still blend. Review candidate 6.",
    unit: "none",
    kind: "boolean",
    default: false,
    defaultReason: EXPERIMENT_REASON,
    home: experimentHome,
    appliesLive: true,
    source: "src/engine/babylon/panorama/panoramaRenderer.ts",
  },
  {
    id: RENDERER_EXPERIMENT_IDS.panoramaShaders,
    label: "Simpler panorama shaders",
    description: "WebGL only: works out each orb's per-draw constants once on the CPU instead of in every pixel, turns the panorama's view into the image's frame in the vertex shader, and normalizes each ray once or, for a cube, not at all. Review candidate 7.",
    unit: "none",
    kind: "boolean",
    default: false,
    defaultReason: EXPERIMENT_REASON,
    home: experimentHome,
    appliesLive: true,
    source: "src/engine/babylon/panorama/panoramaRenderer.ts",
  },
  {
    id: RENDERER_EXPERIMENT_IDS.presentationCandidates,
    label: "Skip the hidden globe during a panorama",
    description: "While a panorama replaces the globe, offers the renderer only the meshes it can draw, instead of preparing every retained map tile twice a frame before hiding it. Review candidate 3.",
    unit: "none",
    kind: "boolean",
    default: false,
    defaultReason: EXPERIMENT_REASON,
    home: experimentHome,
    appliesLive: true,
    source: "src/engine/babylon/presentationCandidates.ts",
  },
];

/** Generic renderer experiments; 360 supplies its own three legacy feature records. */
export const RENDERER_OWNED_EXPERIMENT_PARAMETERS = RENDERER_EXPERIMENT_PARAMETERS.filter(spec =>
  spec.id === RENDERER_EXPERIMENT_IDS.all || spec.id === RENDERER_EXPERIMENT_IDS.presentationCandidates);
/** Temporary exact-data handoff for 360; register these once in the host, never twice. */
export const LEGACY_360_RENDERER_PARAMETER_HANDOFF = RENDERER_EXPERIMENT_PARAMETERS.filter(spec =>
  spec.id !== RENDERER_EXPERIMENT_IDS.all && spec.id !== RENDERER_EXPERIMENT_IDS.presentationCandidates);
