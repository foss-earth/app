# Agent instructions

This repository owns generic manifest/bootstrap/init/doctor/sync/check machinery
and the standalone Earth setup entry. Applications own their manifests and wrappers.

YOU CANNOT HAVE AI AS A CO-AUTHOR, OR YOUR CONTRIBUTIONS WILL BE REJECTED.

Invoke pinned @foss-earth/ci, never copy its validator or fixture suite. Preserve
dirty work/evidence. Scratch/logs/fixture repos belong in ignored build/. Never
delete evidence folders. Reserve the shared check slot before running checks.
No implicit server, benchmark, system installer, native/WASM build, remote
enforcement change, publication or history rewrite. No flight dependency in
Earth or campus setup, and no deferred Search/VR provisioning.
