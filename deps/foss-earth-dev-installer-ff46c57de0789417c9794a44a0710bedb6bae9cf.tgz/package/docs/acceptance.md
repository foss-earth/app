# Acceptance status

Current implementation has local fixture tests for first/repeated init, read-only
doctor, selected closure/full default, exact upgrade, dirty/diverged work,
unavailable source, corrupt artifact, failed/interrupted resume, argument/path
spaces, escape/symlink/collision, prerequisites and explicit local links.
Synthetic Earth/campus/flight manifests exercise shared bootstrap without an
application checkout or private content. Fixtures are ignored local repos.
No prohibited attribution commits are created here; attribution fixtures remain
in the single common @foss-earth/ci component.

The coordinator granted the sequential installer verification window on
2026-10-09. Targeted local safety fixtures passed after repairing a fixture that
enabled links before creating its provider. The original failure and causal
rerun are retained. Final suite, exact committed-source packing, independent
archive reproduction, installed public entry points, common conformance and
complete intended-ref audit receipts are recorded in the Platform handoff.
Qualification is limited to macOS arm64, Node 26.9.0 and Git 2.54.0 (Apple Git-157).
Node syntax/JSON checks are not TypeScript analysis. Declared Node 22 compatibility
and Linux/Windows are unqualified until actually tested. No app/native/GPU/device
qualification is inferred.

Real acceptance additionally needs Earth-owned full default manifest/artifacts
and default bootstrap descriptor, flight wrapper+manifest+adopted JSBSim artifact,
UMN wrapper+manifest+ordinary prepared content, exact shared installer/tool pins,
clean supported-platform setup and component-selection receipts. Those primary
owners supply compatible release data and wrappers. Missing real artifacts or
remote admission remain incomplete gates; synthetic fixtures do not replace them.

Each repository installs the same immutable @foss-earth/ci component, caller and
policy, and proves its installed entry point with shared conformance. Platform
hands installer source/artifact/consumer results to coordinator for actual remote
enforcement. No copied validator, language/path skip, publication or deployment.
