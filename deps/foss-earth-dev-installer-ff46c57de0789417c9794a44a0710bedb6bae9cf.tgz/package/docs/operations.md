# Safe and resumable operations

Init: validate manifest/paths/closure, probe selected prerequisites, inspect every
existing destination before mutation, display plan, stream/verify artifacts,
clone into retained staging, detach at exact pins, atomically adopt into absent
destinations, and run dependency-ordered installs/builds. No global tool changes.

Doctor: offline read-only probes, tool versions, missing/dirty/diverged/source-pin
state, links and artifact hashes. Git optional locks, fsmonitor and untracked
cache writes/helpers are disabled. No mkdir, fetch or journal/log write.
An offline remote tracking ref is not proof of current upstream state.

Sync: requires a clean checkout from the declared source. Fetch exact target,
prove current commit is its ancestor, and detach at the target; otherwise stop
with manual repair instructions. Existing branch refs/local commits remain.
Checkout explicitly refuses overwriting ignored files; newly tracked paths
cannot destroy retained build/evidence bytes during an otherwise clean upgrade.
Ordinary init does not silently upgrade. Linked worktrees/external Git directories
are rejected as mutation destinations; use a standalone manifest checkout.

Check: source/artifacts must already exist at exact pins; run selected declared
checks, always, with retained command output. It never clones or installs missing
dependencies and never starts a server. Component owners keep domain validation.
Check verifies existing development links and prepared trees; link establishment
and extraction occur only during explicit init/sync operations. Exact mode
refuses mutable neighboring-source package symlinks.

Every resumable build fingerprint includes verified manifest digest, closure,
mode, exact source, step/argv/output contract, opt-ins, prerequisite versions and
dependency output evidence. Completed outputs are rehashed before skipping.
Changed inputs or outputs invalidate success. Failed steps never get success
receipts; truncated/interrupted journal tails are retained and separated before
new records. Staged partial bytes and failed checkouts/logs are not deleted.
Resume the same operation after fixing the exact prerequisite/source/build cause.

Commands run only declared trusted manifest argv, with workspace-local npm cache
and TMPDIR. No shell expansion or secrets in manifest fields. Component build
scripts remain application-owned code and must obey the manifest's category;
review manifests before --apply. Source/ref strings never become shell code.
