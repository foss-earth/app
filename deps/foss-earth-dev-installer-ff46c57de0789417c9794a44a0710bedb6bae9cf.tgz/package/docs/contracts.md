# Manifest, bootstrap and wrapper v1

Application-owned workspace schemaVersion 1:

```json
{
  "schemaVersion": 1,
  "id": "earth-workspace",
  "version": "REVIEWED_RELEASE_VERSION",
  "owner": "foss-earth",
  "repositories": [{
    "id": "engine", "repository": "foss-earth/engine",
    "source": "https://github.com/foss-earth/engine.git",
    "revision": "EXACT_FULL_COMMIT_OID", "destination": "engine",
    "dependsOn": [],
    "steps": [{ "id": "build", "kind": "build", "argv": ["npm", "run", "build"], "outputs": ["dist/release-receipt.json"] }]
  }],
  "artifacts": [], "defaultComponents": ["engine"],
  "selections": { "engine": ["engine"] },
  "prerequisites": [{ "id": "node", "argv": ["node", "--version"], "minimumVersion": "22.0.0" }],
  "verification": { "maxFileBytes": 67108864 }
}
```

This example describes the contract, not a required manifest or released fleet.
Actual manifests need exact accepted pins. `defaultComponents` plus dependency
closure includes every nonoptional repo/artifact; optional content/native work
is explicitly selected. IDs are distinct across repository/artifact types and
the dependency graph must be acyclic. An artifact records id/location/sha256/
sizeBytes/destination, optional and optional dependency IDs. For campus, declare
the versioned prepared content needed for ordinary onboarding, never private
YouVisit backup. Earth/campus owners exclude flight tools/content/repositories.
No runtime import or reverse installer/application dependency is introduced.

Destinations and output paths are normalized relative paths within their chosen
root, with no parent escape, absolute path, backslash, symlink ancestry, collision
or parent/child destination overlap. Workspace build/ is installer state/evidence.
No credentials or machine-specific paths go into published manifests. Local file
sources exist for isolated tests; published manifests use canonical URLs and
artifacts. SHA-256 and declared byte counts are validated before adoption.
HTTPS downloads stream with exact declared size/digest; cache conflicts fail
without overwriting. Redirecting GitHub release assets are supported through a
bounded manual HTTPS-only redirect chain. Defaults are maxRedirects 5 and
requestTimeoutSeconds 30; manifest.transport may name both bounds. Original
manifest URLs contain no credentials/query tokens; server-issued signed HTTPS
redirect targets may contain queries. No authorization or personal headers are
forwarded. File fixtures exercise transport locally; actual immutable release
hosting and credentials remain coordinator decisions.

An artifact may declare archive {format, destination, stripComponents, files,
treeSha256, maxEntries, maxExpandedBytes, maxTarBytes, maxMetadataBytes}. Format is
tar or tar.gz; files maps every exact installed relative file to SHA-256;
treeSha256 hashes JSON.stringify of file/digest pairs sorted by JavaScript string
order. maxEntries bounds archive entries and installed files/directories;
maxExpandedBytes bounds declared payload bytes, maxTarBytes bounds ALL decoded
tar bytes including padding, and maxMetadataBytes defaults to 65536 for global
comment/timestamp metadata. All other bounds are explicitly owner-supplied.
Links/devices/sparse/extended path metadata, escapes, duplicate portable aliases,
unknown/missing/corrupt files and truncated streams fail. Prepared trees use
independent destinations outside source checkouts/artifact files/build state.
Extraction is staged, verified and atomically adopted only into an absent path;
conflicts/failed partial trees are preserved. Doctor/check verify the complete
installed tree without extraction. No media encoding/upload is performed.

Step kind is install/build/check. `argv` is an argument array, never shell text;
tokens `{workspace}`, `{repo:ID}`, `{artifact:ID}`, `{artifactTree:ID}` expand within each single
argument without word splitting. Outputs are exact regular-file receipts/artifacts,
not directory mtimes. `verification.maxFileBytes` is a positive byte bound,
default 64 MiB per output, to keep synchronous receipt validation bounded. Use
small digest/provenance receipts for large trees. Artifacts are hashed by stream.
`optIn` is a named explicit choice required for known native/WASM commands;
caller passes `--opt-in NAME` deliberately. There is no native default or WASM
hash-normalization build. Prerequisites use known tool `--version` probes with
optional minimumVersion and forComponents IDs. System tool installation remains
a separate user action. Check commands are not install/build commands.

Bootstrap descriptor schemaVersion 1 contains manifest {location, sha256,
sizeBytes, owner, revision}. Revision is its exact owning source commit, while
sha256 authenticates exact JSON artifact bytes; owner must match parsed manifest.
The descriptor is shipped with the wrapper's reviewed release and shared-tool
artifact pin. Before source exists, the shared CLI verifies/acquires manifest
data to workspace/build/dev-installer/bootstrap/<digest>.json and then applies
the same schema, selection and operation machinery. Doctor reads only an existing
verified cached manifest and reports missing bootstrap otherwise. Wrappers need
neither source checkout nor runtime/private backup to run.

Thin wrapper example (owned by Flight or UMN):

```js
import { runCli } from '@foss-earth/dev-installer';
import { readFileSync } from 'node:fs';
const bootstrap = JSON.parse(readFileSync(new URL('./workspace-bootstrap.json', import.meta.url)));
const result = await runCli({ bootstrap });
process.exitCode = result.exitCode;
```

Explicit `--manifest` or `--bootstrap` overrides wrapper default data, never a
second hardcoded fleet. Earth entry uses the same API and globe-owned descriptor.
`--links` JSON is {schemaVersion:1,repositories:{ID:"relative/existing/path"}};
manifest links [{consumer,provider,package}] define optional local package links.
No global npm-link state changes. Local sources must resolve to exact clean pins.
Only explicitly overridden provider IDs activate package links. Providers must
be selected; shared ordering prepares them before consumers and rejects link
cycles before any mutation. Declared outputs through verified provider links
are read from that provider. Before a non-reused owner install, existing links
are moved to retained evidence so installation cannot write through into source;
links are re-established for subsequent builds. No implicit provider selection.

Each repository may declare installedPackages [{name,version,artifact,files}].
artifact names its exact downloaded dependency artifact and must precede the
consumer through dependsOn closure; files maps installed relative files to
reviewed SHA-256 and includes package.json. Shared verification checks the
actual node_modules package name/version/regular file digests; doctor/check
fail on missing or stale packages. Exact mode rejects package source symlinks.
Explicit development links verify provider commit/source plus package identity.
Invalid package receipts prevent reuse of install steps; the owner still owns
installation argv and complete exported-file inventories. Include every public
runtime/type/data file required by that release, not only a version marker.

Result schemaVersion 1: action, manifest id/version/digest, mode, exact selected
closure, plan, prerequisites/tool versions, repository states, artifact integrity,
resumable step records, issues, complete/clean and exitCode. CLI emits a plan
JSON event before mutations and a final JSON result; public runCli also returns
that result for wrappers. Exit 0 succeeds/clean plan, 1 diagnosis/conflict requiring
manual resolution, 2 failed/incomplete operation or invalid input. Journal records
attempts/fingerprints/output hashes/log names under workspace/build/. No source
URLs, credentials or environment values are emitted in normal result records.

## Public archive API and executable release seal

Import `validateArchive`, `verifyTree`, `installArchive` and `treeDigest` from
`@foss-earth/dev-installer/archive`. `validateArchive(archive, root)` returns
undefined on a valid contract and throws a rule-bearing error otherwise.
`treeDigest(files)` returns the SHA-256 of the sorted exact file/digest pairs.
`await verifyTree({root, archive})` returns {valid, missing, treeSha256, files,
sizeBytes}; absent trees return {valid:false, missing:true}, conflicts return
valid:false, and unsafe paths/links throw. It performs no extraction or writes.
`await installArchive({root, artifactPath, archive, readOnly:false})` verifies
an existing tree or stages bounded extraction and atomically installs a new
tree. It returns {valid:true, reused, treeSha256, files, sizeBytes, destination}.
Read-only mode accepts an existing verified tree and fails on a missing tree.
Conflicts, unsafe inputs and incomplete extraction throw rule-bearing errors;
failed staging is retained. Compressed artifact SHA-256/size verification is
the caller's responsibility before invoking the standalone extraction API;
workspace acquisition already performs that verification.

The clean-source package script creates a deterministic Git archive and an
external release.json. The descriptor records package/version, revision,
sourceTree, artifactSha256 and sizeBytes; packageIdentity binds name/version,
type/license/engines/bin/exports. `files` seals package.json and every runtime
bin/src/schema/default file, including transitive imports. `publicEntries`
binds each declared bin/export target to its exact regular file digest.
`source.files` inventories every committed file with mode/object/SHA-256/bytes;
`source.inventorySha256` binds that complete map. `archive` includes its complete
file map, uncompressed tar SHA-256/size, tree digest, verified round trip and
explicit entry/payload/stream/metadata bounds. LICENSE, provenance, schemas,
fixtures and original dependency notices are retained in the source archive.

Primary writers, including Flight's AUDIO_ARCHIVE_VERIFIER_PIN owner, must use
an independently reviewed descriptor: verify the descriptor pin, archive digest
and size, install with scripts disabled, compare package identity and every
descriptor.files byte before importing a public entry. Pin source, archive,
size and complete executable map together; hashing archive.mjs alone leaves
its imports unverified. Flight then binds the public archive export itself;
no generic parser is copied. The installed-consumer verification script exercises
these exact installed exports in an isolated workspace. Earth/Flight/UMN
wrappers continue to own their accepted manifest/bootstrap pins.
