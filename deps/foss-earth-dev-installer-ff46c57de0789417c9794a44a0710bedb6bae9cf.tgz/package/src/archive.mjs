import { createReadStream, mkdirSync, existsSync, readdirSync, lstatSync, createWriteStream, renameSync } from 'node:fs';
import { createGunzip } from 'node:zlib';
import { createHash, randomUUID } from 'node:crypto';
import { once } from 'node:events';
import { dirname, resolve, relative } from 'node:path';
import { safePath, assertDistinct } from './paths.mjs';
import { hashFile } from './bootstrap.mjs';
import { sha256 } from './manifest.mjs';
import { SetupError } from './process.mjs';

export const treeDigest = files => sha256(JSON.stringify(Object.entries(files).sort(([a], [b]) => a < b ? -1 : a > b ? 1 : 0)));
export function validateArchive(archive, root) {
  if (!archive || !['tar', 'tar.gz'].includes(archive.format) || !Number.isSafeInteger(archive.maxEntries) || archive.maxEntries < 1 || !Number.isSafeInteger(archive.maxExpandedBytes) || archive.maxExpandedBytes < 1 || !Number.isSafeInteger(archive.maxTarBytes) || archive.maxTarBytes < 1024 || !Number.isSafeInteger(archive.stripComponents ?? 0) || (archive.stripComponents ?? 0) < 0 || !archive.files || typeof archive.files !== 'object' || Array.isArray(archive.files)) throw new SetupError('archive.contract', 'Archive needs format, exact file map, destination and explicit entry/payload/decompressed-stream bounds');
  if (archive.maxMetadataBytes !== undefined && (!Number.isSafeInteger(archive.maxMetadataBytes) || archive.maxMetadataBytes < 1)) throw new SetupError('archive.contract', 'Archive metadata byte bound must be a positive integer');
  safePath(root, archive.destination);
  const aliases = new Set(), spellings = new Map();
  for (const [path, digest] of Object.entries(archive.files)) {
    safePath(root, path);
    const alias = path.normalize('NFKC').toLowerCase();
    if (aliases.has(alias) || !/^[a-f0-9]{64}$/.test(digest)) throw new SetupError('archive.file-map', 'Duplicate portable path or invalid exact file digest');
    aliases.add(alias);
    const parts = path.split('/');
    for (let i = 1; i <= parts.length; i++) { const prefix = parts.slice(0, i).join('/'), alias = prefix.normalize('NFKC').toLowerCase(); if (spellings.has(alias) && spellings.get(alias) !== prefix) throw new SetupError('archive.file-map', 'Parent-directory portable aliases have inconsistent spelling'); spellings.set(alias, prefix); }
  }
  if (Object.keys(archive.files).length > archive.maxEntries) throw new SetupError('archive.file-map', 'Expected file map exceeds entry bound');
  assertDistinct([...aliases]);
  const requiredPaths = new Set();
  for (const path of Object.keys(archive.files)) { const parts = path.split('/'); for (let i = 1; i <= parts.length; i++) requiredPaths.add(parts.slice(0, i).join('/')); }
  if (requiredPaths.size > archive.maxEntries) throw new SetupError('archive.file-map', 'Expected files and their parent directories exceed entry bound');
  if (treeDigest(archive.files) !== archive.treeSha256) throw new SetupError('archive.tree-pin', 'File map does not match exact tree digest');
}
export async function verifyTree({ root, archive }) {
  validateArchive(archive, root);
  const target = safePath(root, archive.destination);
  if (!existsSync(target)) return { valid: false, missing: true };
  if (!lstatSync(target).isDirectory()) return { valid: false, missing: false };
  const actual = {}; let bytes = 0, count = 0, entries = 0;
  async function visit(dir) {
    for (const entry of readdirSync(dir, { withFileTypes: true })) {
      if (++entries > archive.maxEntries) return false;
      const path = resolve(dir, entry.name), rel = relative(target, path);
      if (entry.isSymbolicLink()) throw new SetupError('archive.link', 'Installed content tree contains a symbolic link');
      if (entry.isDirectory()) { if (!Object.keys(archive.files).some(file => file.startsWith(`${rel}/`)) || !await visit(path)) return false; }
      else if (entry.isFile()) { count++; bytes += lstatSync(path).size; if (count > archive.maxEntries || bytes > archive.maxExpandedBytes || !archive.files[rel]) return false; actual[rel] = await hashFile(path); }
      else return false;
    }
    return true;
  }
  const complete = await visit(target);
  return { valid: complete && treeDigest(actual) === archive.treeSha256, missing: false, treeSha256: treeDigest(actual), files: count, sizeBytes: bytes };
}
function text(buffer, start, length) { const field = buffer.subarray(start, start + length); const zero = field.indexOf(0); return new TextDecoder('utf-8', { fatal: true }).decode(zero < 0 ? field : field.subarray(0, zero)); }
function octal(buffer, start, length) { const value = text(buffer, start, length).trim(); if (!/^[0-7]+$/.test(value || '0')) throw new SetupError('archive.number', 'Only canonical octal tar sizes/checksums are accepted'); const parsed = Number.parseInt(value || '0', 8); if (!Number.isSafeInteger(parsed)) throw new SetupError('archive.size', 'Tar size exceeds safe integer range'); return parsed; }
export async function installArchive({ root, artifactPath, archive, readOnly = false }) {
  const previous = await verifyTree({ root, archive });
  if (previous.valid) return { ...previous, reused: true, destination: archive.destination };
  if (!previous.missing) throw new SetupError('archive.conflict', 'Existing content tree differs from pinned file map; preserve it and resolve explicitly');
  if (readOnly) throw new SetupError('archive.missing', 'Pinned prepared tree is not installed');
  const target = safePath(root, archive.destination), staging = safePath(root, `build/dev-installer/extraction/${randomUUID()}`); mkdirSync(staging, { recursive: true });
  const input = createReadStream(artifactPath), stream = archive.format === 'tar.gz' ? input.pipe(createGunzip()) : input;
  if (stream !== input) input.on('error', error => stream.destroy(error));
  let pending = Buffer.alloc(0), active = null, padding = 0, zeros = 0, ended = false, count = 0, expanded = 0, tarBytes = 0, outputError;
  const seen = new Set(), actual = {}, spellings = new Map();
  for (const path of Object.keys(archive.files)) { const parts = path.split('/'); for (let i = 1; i <= parts.length; i++) { const prefix = parts.slice(0, i).join('/'); spellings.set(prefix.normalize('NFKC').toLowerCase(), prefix); } }
  try {
    for await (const chunk of stream) {
      tarBytes += chunk.length;
      if (tarBytes > archive.maxTarBytes) throw new SetupError('archive.stream-bound', 'Decompressed tar stream including header/padding/trailing bytes exceeds its named bound');
      if (outputError) throw outputError;
      pending = pending.length ? Buffer.concat([pending, chunk]) : chunk;
      while (pending.length) {
        if (ended) { if (pending.some(byte => byte !== 0)) throw new SetupError('archive.trailing', 'Nonzero data after tar terminator'); pending = Buffer.alloc(0); break; }
        if (active) {
          const take = Math.min(active.remaining, pending.length), bytes = pending.subarray(0, take); pending = pending.subarray(take); active.remaining -= take;
          if (active.output) { active.hash.update(bytes); if (!active.output.write(bytes)) await once(active.output, 'drain'); }
          else active.metadata.push(bytes);
          if (active.remaining) break;
          if (active.output) { active.output.end(); await once(active.output, 'finish'); const digest = active.hash.digest('hex'); if (digest !== archive.files[active.path]) throw new SetupError('archive.file-digest', 'Extracted file differs from the exact owner file map'); actual[active.path] = digest; }
          else { const metadata = Buffer.concat(active.metadata).toString('utf8'); if (metadata.split('\n').filter(Boolean).some(line => !/^\d+ (comment|mtime|atime|ctime)=/.test(line))) throw new SetupError('archive.pax', 'Unsupported PAX path/link/sparse or global metadata'); }
          padding = (512 - active.size % 512) % 512; active = null;
        }
        if (padding) { const take = Math.min(padding, pending.length); pending = pending.subarray(take); padding -= take; if (padding) break; }
        if (pending.length < 512) break;
        const header = pending.subarray(0, 512); pending = pending.subarray(512);
        if (header.every(byte => byte === 0)) { if (++zeros === 2) ended = true; continue; }
        if (zeros) throw new SetupError('archive.terminator', 'Malformed tar terminator');
        const checksum = octal(header, 148, 8); let sum = 0; for (let i = 0; i < 512; i++) sum += i >= 148 && i < 156 ? 32 : header[i]; if (sum !== checksum) throw new SetupError('archive.checksum', 'Tar header checksum failed');
        const name = text(header, 0, 100), prefix = text(header, 345, 155), type = String.fromCharCode(header[156] || 48), size = octal(header, 124, 12);
        if (++count > archive.maxEntries || (expanded += size) > archive.maxExpandedBytes) throw new SetupError('archive.bounds', 'Archive exceeds named entry or expanded-byte bounds');
        if (type === 'g') { if (size > (archive.maxMetadataBytes ?? 65536)) throw new SetupError('archive.metadata-bound', 'Global tar metadata exceeds its byte bound'); active = { size, remaining: size, metadata: [] }; continue; }
        if (!['0', '5'].includes(type) || text(header, 157, 100)) throw new SetupError('archive.link-or-special', 'Archive links, devices, sparse and special files are forbidden');
        const full = `${prefix ? `${prefix}/` : ''}${name}`.replace(/^\.\//, '').replace(/\/$/, '');
        if (!full || full.startsWith('/') || /^[A-Za-z]:/.test(full) || full.includes('\\') || full.split('/').some(p => !p || p === '.' || p === '..')) throw new SetupError('archive.path', 'Archive path escapes or aliases its destination');
        const parts = full.split('/').slice(archive.stripComponents ?? 0);
        if (!parts.length) { if (type !== '5' || size) throw new SetupError('archive.strip', 'Stripping removes an actual file'); continue; }
        const path = parts.join('/'), alias = path.normalize('NFKC').toLowerCase();
        for (let i = 1; i <= parts.length; i++) { const prefix = parts.slice(0, i).join('/'), alias = prefix.normalize('NFKC').toLowerCase(); if (spellings.has(alias) && spellings.get(alias) !== prefix) throw new SetupError('archive.collision', 'Archive directory spelling conflicts with portable reviewed paths'); spellings.set(alias, prefix); }
        if (seen.has(alias)) throw new SetupError('archive.collision', 'Duplicate or portable alias collision in archive'); seen.add(alias);
        const output = safePath(staging, path);
        if (type === '5') { if (size) throw new SetupError('archive.directory-size', 'Directory has nonzero payload'); if (!Object.keys(archive.files).some(file => file.startsWith(`${path}/`))) throw new SetupError('archive.unknown-directory', 'Archive contains a directory outside the reviewed file parents'); mkdirSync(output, { recursive: true }); continue; }
        if (!archive.files[path]) throw new SetupError('archive.unknown-file', 'Archive contains a file outside the exact reviewed owner map');
        mkdirSync(dirname(output), { recursive: true });
        active = { path, size, remaining: size, output: createWriteStream(output, { flags: 'wx', mode: 0o644 }), hash: createHash('sha256') };
        active.output.on('error', error => { outputError = error; stream.destroy(error); });
      }
    }
    if (!ended || active || padding || pending.length || treeDigest(actual) !== archive.treeSha256) throw new SetupError('archive.incomplete', 'Archive is truncated or missing reviewed files');
    mkdirSync(dirname(target), { recursive: true }); safePath(root, archive.destination); if (existsSync(target)) throw new SetupError('archive.conflict', 'Content destination appeared during extraction; nothing overwritten'); renameSync(staging, target);
    return { valid: true, reused: false, treeSha256: archive.treeSha256, files: Object.keys(actual).length, sizeBytes: expanded, destination: archive.destination };
  } catch (error) { if (active?.output) active.output.destroy(); input.destroy(); stream.destroy(); throw error; }
}
