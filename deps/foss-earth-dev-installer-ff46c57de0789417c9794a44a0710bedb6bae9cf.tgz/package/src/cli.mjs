import { readFileSync, existsSync } from 'node:fs';
import { resolve } from 'node:path';
import { readManifest } from './manifest.mjs';
import { workspace } from './workspace.mjs';
import { bootstrapManifest, validateBootstrapDescriptor } from './bootstrap.mjs';
import { SetupError } from './process.mjs';

export function parseArguments(args) {
  const [action, ...rest] = args;
  if (!['init', 'doctor', 'sync', 'check'].includes(action)) throw new SetupError('cli.action', 'Use init, doctor, sync or check');
  const options = { action, apply: false, selections: [], optIns: [] };
  for (let i = 0; i < rest.length; i++) {
    const arg = rest[i];
    if (arg === '--apply') { options.apply = true; continue; }
    if (!['--manifest', '--manifest-sha256', '--bootstrap', '--root', '--select', '--links', '--opt-in'].includes(arg) || !rest[i + 1]) throw new SetupError('cli.arguments', 'Unknown option or missing value');
    const value = rest[++i];
    if (arg === '--select') options.selections.push(...value.split(','));
    else if (arg === '--opt-in') options.optIns.push(value);
    else { const key = arg.slice(2); if (options[key]) throw new SetupError('cli.duplicate', 'Duplicate option'); options[key] = value; }
  }
  if (action === 'doctor' && options.apply) throw new SetupError('cli.readonly', 'Doctor is read-only and does not accept --apply');
  if (options.manifest && options.bootstrap) throw new SetupError('cli.source', 'Select one explicit manifest or bootstrap descriptor');
  if (!options.root) throw new SetupError('cli.root', 'Choose an explicit workspace root with --root');
  return options;
}
export async function runCli({ args = process.argv.slice(2), bootstrap, write = text => process.stdout.write(text) } = {}) {
  let result;
  try {
    const options = parseArguments(args), root = resolve(options.root);
    let input;
    if (options.manifest) input = readManifest(options.manifest, options['manifest-sha256']);
    else {
      const descriptor = options.bootstrap ? JSON.parse(readFileSync(options.bootstrap, 'utf8')) : bootstrap;
      if (!descriptor) throw new SetupError('bootstrap.unavailable', 'Application owner has not supplied the accepted default bootstrap descriptor; pass --manifest or --bootstrap with exact reviewed pins');
      validateBootstrapDescriptor(descriptor);
      const bootstrapPlan = [{ kind: 'bootstrap-manifest', owner: descriptor.manifest.owner, revision: descriptor.manifest.revision, sha256: descriptor.manifest.sha256, sizeBytes: descriptor.manifest.sizeBytes }];
      if (!options.apply && options.action !== 'doctor' && options.action !== 'check') {
        result = { schemaVersion: 1, action: options.action, complete: true, clean: true, applied: false, exitCode: 0, plan: bootstrapPlan, next: 'Use --apply to verify/acquire this pinned manifest and display/perform its workspace plan' };
        write(`${JSON.stringify(result, null, 2)}\n`); return result;
      }
      if (options.apply) write(`${JSON.stringify({ schemaVersion: 1, event: 'plan', plan: bootstrapPlan })}\n`);
      input = await bootstrapManifest({ descriptor, root, readOnly: options.action === 'doctor' || options.action === 'check' });
    }
    const linksInput = options.links ? JSON.parse(readFileSync(options.links, 'utf8')) : null;
    if (linksInput && (linksInput.schemaVersion !== 1 || !linksInput.repositories || typeof linksInput.repositories !== 'object')) throw new SetupError('links.schema', 'Local link file requires schemaVersion 1 and repository path map');
    result = await workspace({ ...options, root, manifest: input.manifest, digest: input.digest, links: linksInput?.repositories ?? {}, onPlan: plan => { if (options.apply || options.action === 'check') write(`${JSON.stringify({ schemaVersion: 1, event: 'plan', plan })}\n`); } });
  } catch (error) { result = { schemaVersion: 1, complete: false, clean: false, exitCode: 2, issues: [{ rule: error.rule ?? 'input.failure', detail: error instanceof SetupError ? error.message : 'Cannot read/validate input or source; retained work is unchanged or repairable' }] }; }
  write(`${JSON.stringify(result, null, 2)}\n`); return result;
}
