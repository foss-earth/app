import { existsSync, mkdirSync, readFileSync, writeFileSync, appendFileSync, renameSync, statSync, readdirSync, symlinkSync, lstatSync, realpathSync } from 'node:fs';
import { resolve, dirname, relative } from 'node:path';
import { randomUUID } from 'node:crypto';
import { command, git, SetupError } from './process.mjs';
import { safePath, assertDistinct } from './paths.mjs';
import { validateManifest, selectComponents, sha256 } from './manifest.mjs';
import { acquire, hashFile } from './bootstrap.mjs';
import { verifyTree, installArchive } from './archive.mjs';
import { verifyPackageIdentity } from './packages.mjs';

function stateOf(path, item) {
  if (!existsSync(path)) return { exists: false, missing: true };
  const top = git(path, ['rev-parse', '--show-toplevel'], true);
  if (top.status !== 0 || resolve(top.stdout.trim()) !== resolve(path)) return { exists: true, conflict: 'Destination is not the intended standalone repository' };
  if (git(path, ['rev-parse', '--absolute-git-dir']).stdout.trim() !== resolve(path, '.git')) return { exists: true, conflict: 'Linked worktree or external Git directory is outside the safe standalone checkout contract' };
  const revision = git(path, ['rev-parse', 'HEAD']).stdout.trim();
  const dirty = git(path, ['status', '--porcelain', '--untracked-files=normal']).stdout.trim().length > 0;
  const origin = git(path, ['remote', 'get-url', 'origin'], true);
  const sourceMatches = origin.status === 0 && origin.stdout.trim() === item.source;
  const targetAvailable = git(path, ['cat-file', '-e', `${item.revision}^{commit}`], true).status === 0;
  const divergence = targetAvailable ? git(path, ['merge-base', '--is-ancestor', revision, item.revision], true).status !== 0 : null;
  return { exists: true, revision, dirty, sourceMatches, compatible: revision === item.revision, diverged: divergence, targetAvailable, remoteFreshness: 'unknown; offline doctor does not fetch' };
}
function outputsDigest(path, outputs, limit = 64 * 1024 * 1024, linkedOutputs = new Map()) {
  const values = [];
  for (const output of outputs) {
    let target;
    for (const [name, provider] of linkedOutputs) {
      const prefix = `node_modules/${name}/`;
      if (!output.startsWith(prefix)) continue;
      const installed = safePath(path, prefix.slice(0, -1), { allowLeafSymlink: true });
      if (existsSync(installed) && lstatSync(installed).isSymbolicLink()) {
        if (!existsSync(provider) || realpathSync(installed) !== realpathSync(provider)) throw new SetupError('links.conflict', 'Output link does not resolve to the declared provider');
        target = safePath(provider, output.slice(prefix.length));
      }
    }
    target ??= safePath(path, output);
    if (!existsSync(target)) return null;
    const stat = statSync(target);
    if (!stat.isFile() || stat.size > limit) throw new SetupError('output.verification', 'Declared output must be a regular file within verification.maxFileBytes; declare exact artifact receipts for directories');
    values.push([output, sha256(readFileSync(target))]);
  }
  return sha256(JSON.stringify(values));
}
export async function workspace({ action, root, manifest, digest, selections = [], apply = false, links = {}, optIns = [], onPlan = () => {} }) {
  if (!['init', 'doctor', 'sync', 'check'].includes(action)) throw new SetupError('workspace.action', 'Unsupported operation');
  if (!/^[a-f0-9]{64}$/.test(digest)) throw new SetupError('manifest.digest', 'Operations require the verified manifest artifact SHA-256');
  const validated = validateManifest(manifest, root); let selected = selectComponents(validated, selections);
  const result = { schemaVersion: 1, action, manifest: { id: manifest.id, version: manifest.version, sha256: digest }, mode: Object.keys(links).length ? 'local-link' : 'exact', selection: selected.map(i => i.id), plan: [], prerequisites: [], repositories: [], artifacts: [], installedPackages: [], steps: [], issues: [], complete: false, clean: false };
  const locations = new Map(selected.filter(i => !i.artifact).map(i => [i.id, safePath(root, links[i.id] ?? i.destination)]));
  assertDistinct([...locations.values(), ...selected.filter(i => i.artifact).flatMap(i => [safePath(root, i.destination), ...i.archive ? [safePath(root, i.archive.destination)] : []])]);
  if (Object.keys(links).some(id => !locations.has(id))) throw new SetupError('links.selection', 'Local-link overrides must refer to selected repositories');
  const activeLinks = (manifest.links ?? []).filter(link => links[link.provider] && locations.has(link.consumer));
  const ordered = [], visiting = new Set(), visited = new Set(), selectedItems = new Map(selected.map(item => [item.id, item]));
  function order(id) {
    if (visiting.has(id)) throw new SetupError('links.cycle', 'Local source linking creates a dependency cycle'); if (visited.has(id)) return;
    if (!selectedItems.has(id)) throw new SetupError('links.selection', 'Selected local-link consumer requires its provider selection before any operation');
    visiting.add(id); for (const dep of [...selectedItems.get(id).dependsOn ?? [], ...activeLinks.filter(link => link.consumer === id).map(link => link.provider)]) order(dep);
    visiting.delete(id); visited.add(id); ordered.push(selectedItems.get(id));
  }
  selected.forEach(item => order(item.id)); selected = ordered; result.selection = selected.map(item => item.id);
  const readonly = action === 'doctor' || (!apply && action !== 'check');
  for (const item of selected) result.plan.push(item.artifact ? { kind: 'artifact', id: item.id, sizeBytes: item.sizeBytes, sha256: item.sha256, destination: item.destination } : { kind: links[item.id] ? 'verify-local-source' : 'checkout', id: item.id, revision: item.revision, destination: relative(resolve(root), locations.get(item.id)), steps: (item.steps ?? []).filter(step => (action === 'check' ? step.kind === 'check' : step.kind !== 'check') && (!step.optIn || optIns.includes(step.optIn))).map(step => ({ id: step.id, kind: step.kind, argv: step.argv })) });
  for (const item of selected.filter(i => i.artifact && i.archive)) result.plan.push({ kind: 'prepared-tree', id: item.id, destination: item.archive.destination, treeSha256: item.archive.treeSha256, maxEntries: item.archive.maxEntries, maxExpandedBytes: item.archive.maxExpandedBytes, maxTarBytes: item.archive.maxTarBytes });
  for (const prerequisite of manifest.prerequisites ?? []) {
    if (prerequisite.forComponents && !prerequisite.forComponents.some(id => result.selection.includes(id))) continue;
    const run = command(prerequisite.argv, { allowFailure: true });
    const match = /\d+\.\d+(?:\.\d+)?/.exec(run.stdout + run.stderr);
    const actual = match?.[0] ?? null;
    let pass = run.status === 0 && actual !== null;
    if (pass && prerequisite.minimumVersion) { const a = actual.split('.').map(Number), b = prerequisite.minimumVersion.split('.').map(Number); pass = [0, 1, 2].some(i => (a[i] ?? 0) > (b[i] ?? 0) && a.slice(0, i).every((v, j) => v === b[j])) || [0, 1, 2].every(i => (a[i] ?? 0) === (b[i] ?? 0)); }
    result.prerequisites.push({ id: prerequisite.id, version: actual, pass });
    if (!pass) result.issues.push({ rule: 'prerequisite.failed', component: prerequisite.id, repair: 'Install/update this tool explicitly outside the installer, then rerun' });
  }
  // Inspect every selected destination before any fetch/build mutation.
  for (const item of selected.filter(i => !i.artifact)) {
    const state = stateOf(locations.get(item.id), item); result.repositories.push({ id: item.id, ...state, localLink: Boolean(links[item.id]) });
    if (state.conflict || state.dirty || state.diverged || (state.exists && !state.sourceMatches) || (links[item.id] && !state.compatible)) result.issues.push({ rule: state.dirty ? 'repository.dirty' : state.diverged ? 'repository.diverged' : 'repository.conflict', component: item.id, repair: 'Preserve local work/evidence. Commit or resolve it yourself; reconcile source/pin or choose an empty destination. No reset, clean, stash or deletion is performed' });
    else if ((['doctor', 'check'].includes(action) && !state.exists) || state.exists && !state.compatible && action !== 'sync') result.issues.push({ rule: !state.exists ? 'repository.missing' : 'repository.pin', component: item.id, repair: 'Run explicit init/sync after reviewing the plan' });
  }
  for (const item of selected.filter(i => i.artifact)) {
    const path = safePath(root, item.destination);
    const valid = existsSync(path) && statSync(path).isFile() && statSync(path).size === item.sizeBytes && await hashFile(path) === item.sha256;
    result.artifacts.push({ id: item.id, valid, missing: !existsSync(path), sha256: item.sha256 });
    if (existsSync(path) && !valid || ['doctor', 'check'].includes(action) && !valid) result.issues.push({ rule: existsSync(path) ? 'artifact.corrupt' : 'artifact.missing', component: item.id, repair: 'Preserve conflicting bytes; provide the exact pinned artifact or rerun explicit init' });
    if (item.archive) {
      const tree = await verifyTree({ root, archive: item.archive });
      result.artifacts.at(-1).preparedTree = tree;
      if (!tree.valid && (!tree.missing || ['doctor', 'check'].includes(action))) result.issues.push({ rule: tree.missing ? 'archive.missing' : 'archive.conflict', component: item.id, repair: 'Preserve conflicting prepared tree; provide exact reviewed files or run explicit init for missing content' });
    }
  }
  for (const link of manifest.links ?? []) {
    if (!locations.has(link.consumer) || !locations.has(link.provider)) continue;
    const destination = safePath(locations.get(link.consumer), `node_modules/${link.package}`, { allowLeafSymlink: true });
    let stat; try { stat = lstatSync(destination); } catch (error) { if (error.code !== 'ENOENT') throw error; }
    const linked = stat?.isSymbolicLink() && existsSync(destination) && existsSync(locations.get(link.provider)) && realpathSync(destination) === realpathSync(locations.get(link.provider));
    const enabled = activeLinks.includes(link);
    result.plan.push({ kind: 'package-link', package: link.package, consumer: link.consumer, provider: link.provider, enabled, resolved: linked, replacement: 'Existing package directory is moved into retained workspace/build evidence only in explicit local-link mode' });
    if (['doctor', 'check'].includes(action) && enabled && !linked || !enabled && stat?.isSymbolicLink()) result.issues.push({ rule: 'links.identity', component: link.consumer, repair: 'Local-link verification requires the declared source. Exact mode forbids neighboring source symlinks; install reviewed pinned packages explicitly' });
  }
  async function packageState(item, diagnose) {
    const rows = [];
    for (const identity of item.installedPackages ?? []) {
      const link = activeLinks.find(link => link.consumer === item.id && link.package === identity.name);
      let row;
      if (link) {
        const destination = safePath(locations.get(item.id), `node_modules/${identity.name}`, { allowLeafSymlink: true }), provider = locations.get(link.provider);
        let metadata; try { const path = safePath(provider, 'package.json'), stat = lstatSync(path); if (!stat.isFile() || stat.size > (manifest.verification?.maxFileBytes ?? 64 * 1024 * 1024)) throw new SetupError('package.metadata', 'Linked package metadata exceeds the regular-file verification bound'); metadata = JSON.parse(readFileSync(path, 'utf8')); } catch { metadata = null; }
        const state = provider ? stateOf(provider, validated.items.get(link.provider)) : {};
        const valid = Boolean(provider && existsSync(destination) && lstatSync(destination).isSymbolicLink() && existsSync(provider) && realpathSync(destination) === realpathSync(provider) && state.compatible && state.sourceMatches && !state.dirty && !state.conflict && !state.diverged && metadata?.name === identity.name && metadata?.version === identity.version);
        row = { name: identity.name, valid, artifact: identity.artifact, mode: 'local-link', provider: link.provider, revision: validated.items.get(link.provider)?.revision };
      } else { try { row = await verifyPackageIdentity({ repo: locations.get(item.id), identity, maxFileBytes: manifest.verification?.maxFileBytes }); } catch (error) { row = { name: identity.name, valid: false, artifact: identity.artifact, rule: error.rule ?? 'package.identity' }; if (error.rule === 'path.symlink') result.issues.push({ rule: 'package.source-link', component: item.id, package: identity.name, repair: 'Preserve the undeclared package symlink and resolve it explicitly; owner installation cannot follow neighboring source links' }); } }
      rows.push({ consumer: item.id, ...row });
      if (diagnose && !row.valid) result.issues.push({ rule: 'package.identity', component: item.id, package: identity.name, repair: 'Install the exact manifest artifact/version/file set through the owner install step, or resolve the explicit clean source link; preserve conflicting work' });
    }
    return rows;
  }
  for (const item of selected.filter(i => !i.artifact)) result.installedPackages.push(...await packageState(item, ['doctor', 'check'].includes(action)));
  onPlan(result.plan);
  if (readonly || result.issues.length) { result.complete = true; result.clean = result.issues.length === 0; result.exitCode = result.clean ? 0 : 1; return result; }
  const stateRoot = safePath(root, 'build/dev-installer'); mkdirSync(stateRoot, { recursive: true });
  const journal = resolve(stateRoot, 'steps.jsonl'), history = existsSync(journal) ? readFileSync(journal, 'utf8').trim().split('\n').filter(Boolean).flatMap(line => { try { return [JSON.parse(line)]; } catch { return []; } }) : [];
  const records = new Map(history.filter(r => r.fingerprint).map(r => [r.fingerprint, r]));
  const dependencies = new Map();
  let truncated = existsSync(journal) && !readFileSync(journal, 'utf8').endsWith('\n');
  const record = value => { result.steps.push(value); if (truncated) { appendFileSync(journal, '\n'); truncated = false; } appendFileSync(journal, `${JSON.stringify({ ...value, time: new Date().toISOString() })}\n`); };
  try {
    function establishLinks(consumer) {
      if (!Object.keys(links).length || !['init', 'sync'].includes(action)) return;
      for (const link of activeLinks) {
        if (link.consumer !== consumer || !locations.has(link.consumer) || !locations.has(link.provider)) continue;
        const destination = safePath(locations.get(link.consumer), `node_modules/${link.package}`, { allowLeafSymlink: true }), provider = locations.get(link.provider);
        mkdirSync(dirname(destination), { recursive: true });
        if (existsSync(destination)) {
          if (lstatSync(destination).isSymbolicLink()) { if (realpathSync(destination) !== realpathSync(provider)) throw new SetupError('links.conflict', 'Existing development link points elsewhere; resolve explicitly'); else continue; }
          const backup = safePath(root, `build/dev-installer/link-backups/${randomUUID()}`); mkdirSync(dirname(backup), { recursive: true }); renameSync(destination, backup);
        }
        symlinkSync(provider, destination, 'dir');
      }
    }
    function suspendLinks(consumer) {
      for (const link of activeLinks.filter(link => link.consumer === consumer)) {
        const destination = safePath(locations.get(consumer), `node_modules/${link.package}`, { allowLeafSymlink: true });
        let stat; try { stat = lstatSync(destination); } catch (error) { if (error.code === 'ENOENT') continue; throw error; }
        if (!stat.isSymbolicLink()) continue;
        if (!existsSync(destination) || realpathSync(destination) !== realpathSync(locations.get(link.provider))) throw new SetupError('links.conflict', 'Existing output link points elsewhere; no owner install may follow it');
        const backup = safePath(root, `build/dev-installer/link-backups/${randomUUID()}`); mkdirSync(dirname(backup), { recursive: true }); renameSync(destination, backup);
      }
    }
    for (const item of selected) {
      if (item.artifact) {
        if (action === 'check') { if (!result.artifacts.find(a => a.id === item.id).valid) throw new SetupError('artifact.missing', `Required artifact ${item.id} is unavailable`); }
        else { await acquire({ ...item, maxRedirects: manifest.transport?.maxRedirects, requestTimeoutSeconds: manifest.transport?.requestTimeoutSeconds, root }); Object.assign(result.artifacts.find(a => a.id === item.id), { valid: true, missing: false }); }
        if (item.archive) {
          const tree = action === 'check' ? await verifyTree({ root, archive: item.archive }) : await installArchive({ root, artifactPath: safePath(root, item.destination), archive: item.archive });
          if (!tree.valid) throw new SetupError('archive.missing', 'Exact prepared content tree is unavailable');
          result.artifacts.find(a => a.id === item.id).preparedTree = tree;
          record({ id: `tree:${item.id}`, status: 'passed', ...tree });
        }
        dependencies.set(item.id, sha256(JSON.stringify({ sha256: item.sha256, treeSha256: item.archive?.treeSha256 }))); record({ id: `artifact:${item.id}`, status: 'passed', sha256: item.sha256 }); continue;
      }
      const path = locations.get(item.id), old = result.repositories.find(r => r.id === item.id);
      safePath(root, relative(resolve(root), path));
      if (links[item.id]) { if (!old.compatible) throw new SetupError('links.identity', 'Explicit local link must resolve to the exact declared source revision'); }
      else if (!old.exists) {
        if (action === 'check') throw new SetupError('repository.missing', `Required repository ${item.id} is unavailable`);
        const staging = safePath(root, `build/dev-installer/checkouts/${item.id}-${randomUUID()}`); mkdirSync(dirname(staging), { recursive: true });
        git(root, ['clone', '--no-checkout', '--no-hardlinks', '--', item.source, staging]);
        if (git(staging, ['cat-file', '-e', `${item.revision}^{commit}`], true).status !== 0) git(staging, ['fetch', '--no-tags', 'origin', item.revision]);
        git(staging, ['checkout', '--no-overwrite-ignore', '--detach', item.revision]);
        mkdirSync(dirname(path), { recursive: true }); safePath(root, item.destination);
        if (existsSync(path)) throw new SetupError('repository.conflict', 'Destination appeared during clone; retained staging and destination');
        renameSync(staging, path);
      } else if (!old.compatible) {
        if (action !== 'sync') throw new SetupError('repository.pin', 'Existing checkout has a different pin; use explicit sync after reviewing the upgrade');
        git(path, ['fetch', '--no-tags', 'origin', item.revision]);
        const current = stateOf(path, item);
        if (current.dirty || current.diverged || !current.targetAvailable) throw new SetupError('repository.diverged', 'Target cannot fast-forward the local commit; reconcile manually; no local commits discarded');
        git(path, ['checkout', '--no-overwrite-ignore', '--detach', item.revision]);
      }
      if (git(path, ['rev-parse', 'HEAD']).stdout.trim() !== item.revision) throw new SetupError('repository.identity', 'Resolved checkout differs from exact source pin');
      Object.assign(old, stateOf(path, item), { localLink: Boolean(links[item.id]) });
      const evidence = [];
      const linkedOutputs = new Map(activeLinks.filter(link => link.consumer === item.id).map(link => [link.package, locations.get(link.provider)]));
      for (const step of item.steps ?? []) {
        if ((step.kind === 'check') !== (action === 'check') || step.optIn && !optIns.includes(step.optIn)) continue;
        if (step.kind !== 'install') establishLinks(item.id);
        const argv = step.argv.map(arg => arg.replace(/\{workspace\}/g, resolve(root)).replace(/\{repo:([^}]+)\}/g, (_token, id) => { if (!locations.has(id)) throw new SetupError('command.dependency', 'Argument references an unselected repository'); return locations.get(id); }).replace(/\{artifact:([^}]+)\}/g, (_token, id) => { const artifact = validated.items.get(id); if (!artifact?.artifact || !dependencies.has(id)) throw new SetupError('command.dependency', 'Argument references an unprepared artifact'); return safePath(root, artifact.destination); }).replace(/\{artifactTree:([^}]+)\}/g, (_token, id) => { const artifact = validated.items.get(id); if (!artifact?.archive || !dependencies.has(id)) throw new SetupError('command.dependency', 'Argument references an unprepared content tree'); return safePath(root, artifact.archive.destination); }));
        const fingerprint = sha256(JSON.stringify({ digest, selection: result.selection, mode: result.mode, revision: item.revision, stepId: step.id, outputs: step.outputs, argv, optIns, dependencies: [...dependencies], prerequisites: result.prerequisites }));
        const output = outputsDigest(path, step.outputs, manifest.verification?.maxFileBytes, linkedOutputs);
        const previous = records.get(fingerprint);
        const packageRepair = step.kind === 'install' && result.installedPackages.some(row => row.consumer === item.id && !row.valid);
        if (!packageRepair && previous?.status === 'passed' && step.outputs.length && previous.output === output && action !== 'check') { record({ id: `${item.id}:${step.id}`, fingerprint, status: 'passed', output, reused: true }); evidence.push(output); continue; }
        const runId = `${fingerprint}-${randomUUID()}`, logs = safePath(root, `build/dev-installer/commands/${runId}.log`); mkdirSync(dirname(logs), { recursive: true });
        if (step.kind === 'install') suspendLinks(item.id);
        const cache = safePath(root, 'build/dev-installer/npm-cache'), temp = safePath(root, 'build/dev-installer/tmp'); mkdirSync(cache, { recursive: true }); mkdirSync(temp, { recursive: true });
        const run = command(argv, { cwd: path, allowFailure: true, environment: { npm_config_cache: cache, TMPDIR: temp } }); writeFileSync(logs, run.stdout + run.stderr);
        if (run.status !== 0) { record({ id: `${item.id}:${step.id}`, fingerprint, status: 'failed', exitCode: run.status, log: relative(root, logs) }); throw new SetupError('step.failed', `Step ${item.id}:${step.id} failed; fix the cause and rerun to resume`); }
        const checkedSources = [item, ...activeLinks.filter(link => link.consumer === item.id).map(link => validated.items.get(link.provider))];
        let sourceChanged = false;
        for (const sourceItem of checkedSources) {
          const sourceAfterStep = stateOf(locations.get(sourceItem.id), sourceItem);
          Object.assign(result.repositories.find(row => row.id === sourceItem.id), sourceAfterStep);
          sourceChanged ||= !sourceAfterStep.compatible || !sourceAfterStep.sourceMatches || sourceAfterStep.dirty || Boolean(sourceAfterStep.conflict);
        }
        if (sourceChanged) {
          record({ id: `${item.id}:${step.id}`, fingerprint, status: 'failed', rule: 'repository.modified', log: relative(root, logs) });
          throw new SetupError('repository.modified', 'Owner step changed its pinned source or an active linked provider; preserve source/working tree/origin and reconcile before resuming');
        }
        const nextOutput = outputsDigest(path, step.outputs, manifest.verification?.maxFileBytes, linkedOutputs);
        if (step.outputs.length && nextOutput === null) throw new SetupError('step.output', `Step ${item.id}:${step.id} did not produce its declared output`);
        record({ id: `${item.id}:${step.id}`, fingerprint, status: 'passed', output: nextOutput, reused: false, log: relative(root, logs) }); evidence.push(nextOutput);
      }
      establishLinks(item.id);
      const after = stateOf(path, item); Object.assign(old, after);
      if (!after.compatible || !after.sourceMatches || after.dirty || after.conflict) throw new SetupError('repository.modified', 'Owner steps changed the pinned source/working tree/origin; preserve it and reconcile before resuming');
      const installed = await packageState(item, true);
      result.installedPackages = [...result.installedPackages.filter(row => row.consumer !== item.id), ...installed];
      if (installed.some(row => !row.valid)) throw new SetupError('package.identity', 'Resolved installed package does not match the exact artifact identity');
      dependencies.set(item.id, sha256(JSON.stringify({ revision: item.revision, evidence, installed })));
    }
    result.complete = true; result.clean = true; result.exitCode = 0;
  } catch (error) { result.issues.push({ rule: error.rule ?? 'workspace.failure', detail: error instanceof SetupError ? error.message : 'Operation failed; retained workspace and evidence; resolve input/tool/source and resume' }); result.exitCode = 2; }
  writeFileSync(resolve(stateRoot, `result-${randomUUID()}.json`), JSON.stringify(result, null, 2));
  return result;
}
