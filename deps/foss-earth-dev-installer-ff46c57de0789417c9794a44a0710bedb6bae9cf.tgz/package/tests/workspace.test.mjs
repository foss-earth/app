import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdirSync, mkdtempSync, writeFileSync, readFileSync, existsSync, readdirSync, statSync, symlinkSync } from 'node:fs';
import { resolve } from 'node:path';
import { pathToFileURL } from 'node:url';
import { command, git } from '../src/process.mjs';
import { workspace } from '../src/workspace.mjs';
import { sha256, validateManifest, selectComponents } from '../src/manifest.mjs';
import { bootstrapManifest } from '../src/bootstrap.mjs';
import { runCli } from '../src/cli.mjs';

const scratch = resolve('build/fixtures'); mkdirSync(scratch, { recursive: true });
const root = mkdtempSync(resolve(scratch, 'run-')); let serial = 0;
function fixture(name = 'fixture') {
  const source = resolve(root, `source-${name}-${serial++}`); mkdirSync(source, { recursive: true }); git(source, ['init', '--quiet', '--initial-branch=main']);
  writeFileSync(resolve(source, '.gitignore'), '/build/\n/dist/\n/node_modules/\n');
  writeFileSync(resolve(source, 'build.mjs'), 'import {mkdirSync,existsSync,readFileSync,writeFileSync} from "node:fs"; mkdirSync("build",{recursive:true}); if(existsSync("build/fail")) process.exit(5); mkdirSync("dist",{recursive:true}); const count=existsSync("build/count")?Number(readFileSync("build/count")):0; writeFileSync("build/count",String(count+1)); writeFileSync("dist/receipt.json",JSON.stringify({built:true}));\n');
  writeFileSync(resolve(source, 'README.md'), 'Synthetic local source; no personal data.\n');
  git(source, ['add', '.gitignore', 'README.md', 'build.mjs']);
  git(source, ['-c', 'user.name=Fixture Human', '-c', 'user.email=fixture@example.invalid', 'commit', '--quiet', '-m', 'Synthetic source']);
  const revision = git(source, ['rev-parse', 'HEAD']).stdout.trim();
  const artifact = resolve(root, `artifact-${serial}.txt`), bytes = Buffer.from('exact synthetic artifact'); writeFileSync(artifact, bytes);
  const manifest = { schemaVersion: 1, id: name, version: '1.0.0', owner: 'synthetic-owner', repositories: [{ id: 'app', repository: 'fixture/app', destination: 'app', source: pathToFileURL(source).href, revision, dependsOn: ['content'], steps: [{ id: 'build', kind: 'build', argv: ['node', 'build.mjs'], outputs: ['dist/receipt.json'] }, { id: 'check', kind: 'check', argv: ['node', '-e', 'if(!require("node:fs").existsSync("dist/receipt.json"))process.exit(3)'], outputs: [] }] }], artifacts: [{ id: 'content', location: pathToFileURL(artifact).href, sha256: sha256(bytes), sizeBytes: bytes.length, destination: 'artifacts/content.txt' }], defaultComponents: ['app'], selections: { minimal: ['app'] }, prerequisites: [{ id: 'node', argv: ['node', '--version'], minimumVersion: '22.0.0' }, { id: 'git', argv: ['git', '--version'] }] };
  const destination = resolve(root, `workspace ${name} ${serial++}`);
  const run = (action = 'init', extra = {}) => workspace({ action, root: destination, manifest, digest: sha256(JSON.stringify(manifest)), apply: true, ...extra });
  return { source, manifest, destination, run, artifact };
}
test('first full init, repeat init verifies and reuses outputs, spaces, check, plan precedes action', async () => {
  const f = fixture('earth'); let planned = false;
  const result = await f.run('init', { onPlan: plan => { assert.equal(existsSync(resolve(f.destination, 'app')), false); assert.ok(plan.some(p => p.kind === 'artifact')); planned = true; } });
  assert.equal(result.exitCode, 0); assert.equal(planned, true);
  assert.equal(readFileSync(resolve(f.destination, 'app/build/count'), 'utf8'), '1');
  const repeat = await f.run(); assert.equal(repeat.exitCode, 0); assert.ok(repeat.steps.some(s => s.reused));
  assert.equal(readFileSync(resolve(f.destination, 'app/build/count'), 'utf8'), '1');
  assert.equal((await f.run('check')).exitCode, 0);
  writeFileSync(resolve(f.destination, 'app/dist/receipt.json'), 'tampered output');
  assert.equal((await f.run()).exitCode, 0); assert.equal(readFileSync(resolve(f.destination, 'app/build/count'), 'utf8'), '2');
});
function snapshot(path) {
  const files = [];
  if (!existsSync(path)) return files;
  for (const entry of readdirSync(path, { withFileTypes: true })) { const p = resolve(path, entry.name); if (entry.isDirectory()) files.push(...snapshot(p)); else if (entry.isFile()) files.push([p, statSync(p).mtimeMs, sha256(readFileSync(p))]); }
  return files;
}
test('doctor is read-only offline, including missing root and no cache creation', async () => {
  const f = fixture('doctor'); const missing = await f.run('doctor'); assert.equal(missing.exitCode, 1); assert.equal(existsSync(f.destination), false);
  await f.run(); const before = snapshot(f.destination); const result = await f.run('doctor'); assert.equal(result.exitCode, 0); assert.deepEqual(snapshot(f.destination), before);
  assert.equal(result.repositories[0].remoteFreshness.includes('unknown'), true);
});
test('selection dependency closure, full default and optional component isolation', () => {
  const f = fixture('selection'), repo = f.manifest.repositories[0];
  f.manifest.repositories.push({ ...repo, id: 'library', repository: 'fixture/library', destination: 'library', dependsOn: [], steps: [] }, { ...repo, id: 'optional', repository: 'fixture/optional', destination: 'optional', dependsOn: [], optional: true, steps: [] });
  repo.dependsOn.push('library'); f.manifest.selections.library = ['library'];
  const validated = validateManifest(f.manifest, f.destination);
  assert.deepEqual(selectComponents(validated, ['library']).map(i => i.id), ['library']);
  assert.deepEqual(selectComponents(validated).map(i => i.id), ['content', 'library', 'app']);
  const broken = structuredClone(f.manifest); broken.repositories.at(-1).optional = false; assert.throws(() => validateManifest(broken, f.destination));
  for (const provider of ['library', 'optional']) { const duplicate = structuredClone(f.manifest); duplicate.links = [{ consumer: 'app', provider: 'library', package: '@fixture/library' }, { consumer: 'app', provider, package: '@fixture/library' }]; assert.throws(() => validateManifest(duplicate, f.destination), /unique provider/); }
});
test('upgrade fast-forwards exact pins; init requires explicit sync; local commits/divergence preserved', async () => {
  const f = fixture('upgrade'); await f.run();
  writeFileSync(resolve(f.source, 'README.md'), 'New synthetic source version\n'); git(f.source, ['add', 'README.md']); git(f.source, ['-c', 'user.name=Fixture Human', '-c', 'user.email=fixture@example.invalid', 'commit', '--quiet', '-m', 'Upgrade fixture']);
  f.manifest.repositories[0].revision = git(f.source, ['rev-parse', 'HEAD']).stdout.trim(); f.manifest.version = '1.1.0';
  const before = snapshot(f.destination); assert.equal((await f.run()).exitCode, 1); assert.deepEqual(snapshot(f.destination), before); assert.equal((await f.run('sync')).exitCode, 0);
  const repo = resolve(f.destination, 'app'); writeFileSync(resolve(repo, 'README.md'), 'Local preserved commit\n'); git(repo, ['add', 'README.md']); git(repo, ['-c', 'user.name=Fixture Human', '-c', 'user.email=fixture@example.invalid', 'commit', '--quiet', '-m', 'Local change']);
  const local = git(repo, ['rev-parse', 'HEAD']).stdout; assert.equal((await f.run('sync')).exitCode, 1); assert.equal(git(repo, ['rev-parse', 'HEAD']).stdout, local);
});
test('dirty tracked/untracked work and retained evidence block without reset/stash', async () => {
  const f = fixture('dirty'); await f.run(); const repo = resolve(f.destination, 'app'); writeFileSync(resolve(repo, 'README.md'), 'dirty preserved bytes'); writeFileSync(resolve(repo, 'untracked.txt'), 'user file'); writeFileSync(resolve(repo, 'build/evidence.txt'), 'irreplaceable');
  const before = snapshot(f.destination); assert.equal((await f.run('sync')).exitCode, 1); assert.deepEqual(snapshot(f.destination), before);
});
test('upgrade refuses a newly tracked path that would overwrite ignored evidence', async () => {
  const f = fixture('ignored-collision'); await f.run(); const repo = resolve(f.destination, 'app'), evidence = resolve(repo, 'build/evidence.txt'); writeFileSync(evidence, 'irreplaceable ignored evidence');
  mkdirSync(resolve(f.source, 'build'), { recursive: true }); writeFileSync(resolve(f.source, 'build/evidence.txt'), 'new tracked source path'); git(f.source, ['add', '--force', 'build/evidence.txt']); git(f.source, ['-c', 'user.name=Fixture Human', '-c', 'user.email=fixture@example.invalid', 'commit', '--quiet', '-m', 'Synthetic tracked-path upgrade']);
  f.manifest.repositories[0].revision = git(f.source, ['rev-parse', 'HEAD']).stdout.trim(); const old = git(repo, ['rev-parse', 'HEAD']).stdout;
  assert.equal((await f.run('sync')).exitCode, 2); assert.equal(readFileSync(evidence, 'utf8'), 'irreplaceable ignored evidence'); assert.equal(git(repo, ['rev-parse', 'HEAD']).stdout, old);
});
test('unavailable source and corrupt artifact preserve repairable workspace', async () => {
  const f = fixture('unavailable'); f.manifest.repositories[0].source = pathToFileURL(resolve(root, 'not-available')).href;
  assert.equal((await f.run()).exitCode, 2); assert.equal(existsSync(resolve(f.destination, 'app')), false); assert.equal(existsSync(resolve(f.destination, 'artifacts/content.txt')), true);
  const corrupt = fixture('corrupt'); writeFileSync(corrupt.artifact, 'corrupt'); assert.equal((await corrupt.run()).exitCode, 2); assert.equal(existsSync(resolve(corrupt.destination, 'app')), false);
});
test('interrupted/failed build resumes after repair and retains downloads/completed steps', async () => {
  const f = fixture('resume'); const prepare = structuredClone(f.manifest); prepare.repositories[0].steps = [];
  assert.equal((await f.run('init', { manifest: prepare, digest: sha256(JSON.stringify(prepare)) })).exitCode, 0);
  mkdirSync(resolve(f.destination, 'app/build'), { recursive: true });
  writeFileSync(resolve(f.destination, 'app/build/fail'), '', { flag: 'w' });
  assert.equal((await f.run()).exitCode, 2);
  // Removing the fixture failure flag is simulated by renaming it into evidence, never deleting.
  const { renameSync } = await import('node:fs'); renameSync(resolve(f.destination, 'app/build/fail'), resolve(f.destination, 'app/build/repaired-failure-flag'));
  const receipt = resolve(f.destination, 'artifacts/content.txt'), mtime = statSync(receipt).mtimeMs;
  const { appendFileSync } = await import('node:fs'); appendFileSync(resolve(f.destination, 'build/dev-installer/steps.jsonl'), '{"interrupted":');
  assert.equal((await f.run()).exitCode, 0); assert.equal(statSync(receipt).mtimeMs, mtime); assert.ok(readFileSync(resolve(f.destination, 'build/dev-installer/steps.jsonl'), 'utf8').includes('"failed"'));
});
for (const target of ['owner', 'linked-provider']) test(`a build that modifies ${target} source cannot leave a reusable success receipt`, async () => {
  const f = fixture(`source-receipt-${target}`);
  const script = readFileSync(resolve(f.source, 'build.mjs'), 'utf8');
  writeFileSync(resolve(f.source, 'build.mjs'), `${script}\nif(existsSync('build/taint-source')) writeFileSync(${JSON.stringify(target === 'owner' ? 'README.md' : 'node_modules/@fixture/library/README.md')}, 'changed source during build');\n`);
  git(f.source, ['add', 'build.mjs']); git(f.source, ['-c', 'user.name=Fixture Human', '-c', 'user.email=fixture@example.invalid', 'commit', '--quiet', '-m', 'Synthetic source-mutating build fixture']);
  f.manifest.repositories[0].revision = git(f.source, ['rev-parse', 'HEAD']).stdout.trim();
  let links = {};
  if (target === 'linked-provider') {
    f.manifest.repositories.push({ ...f.manifest.repositories[0], id: 'library', repository: 'fixture/library', destination: 'library', dependsOn: [], steps: [] });
    f.manifest.repositories[0].dependsOn.push('library'); f.manifest.links = [{ consumer: 'app', provider: 'library', package: '@fixture/library' }]; links = { library: 'library' };
  }
  const prepare = structuredClone(f.manifest); prepare.repositories[0].steps = [];
  assert.equal((await f.run('init', { manifest: prepare, digest: sha256(JSON.stringify(prepare)) })).exitCode, 0);
  if (target === 'linked-provider') assert.equal((await f.run('init', { manifest: prepare, digest: sha256(JSON.stringify(prepare)), links })).exitCode, 0);
  const repo = resolve(f.destination, 'app'), sourceFile = resolve(f.destination, target === 'owner' ? 'app/README.md' : 'library/README.md'), original = readFileSync(sourceFile);
  mkdirSync(resolve(repo, 'build'), { recursive: true }); writeFileSync(resolve(repo, 'build/taint-source'), 'synthetic trigger');
  const failed = await f.run('init', { links }); assert.equal(failed.exitCode, 2); assert.equal(failed.issues[0].rule, 'repository.modified');
  assert.equal(readFileSync(resolve(repo, 'build/count'), 'utf8'), '1');
  const { renameSync } = await import('node:fs'); renameSync(resolve(repo, 'build/taint-source'), resolve(repo, 'build/retained-taint-trigger')); writeFileSync(sourceFile, original);
  const repaired = await f.run('init', { links }); assert.equal(repaired.exitCode, 0); assert.equal(readFileSync(resolve(repo, 'build/count'), 'utf8'), '2');
  assert.equal(repaired.steps.find(step => step.id === 'app:build').reused, false);
});
test('failed prerequisite and planned init perform no workspace mutation', async () => {
  const f = fixture('prerequisite'); f.manifest.prerequisites[0].minimumVersion = '999.0.0';
  assert.equal((await f.run()).exitCode, 1); assert.equal(existsSync(f.destination), false);
  f.manifest.prerequisites[0].minimumVersion = '22.0.0';
  assert.equal((await f.run('init', { apply: false })).exitCode, 0); assert.equal(existsSync(f.destination), false);
});
test('explicit local-link mode resolves exact clean source identities before builds', async () => {
  const f = fixture('local-link'); const library = { ...f.manifest.repositories[0], id: 'library', repository: 'fixture/library', destination: 'library', dependsOn: [], steps: [] };
  f.manifest.repositories.push(library); f.manifest.repositories[0].dependsOn.push('library'); f.manifest.links = [{ consumer: 'app', provider: 'library', package: '@fixture/library' }];
  assert.equal((await f.run()).exitCode, 0);
  const result = await f.run('init', { links: { library: 'library' } }); assert.equal(result.exitCode, 0); assert.equal(result.mode, 'local-link');
  const { realpathSync } = await import('node:fs'); assert.equal(realpathSync(resolve(f.destination, 'app/node_modules/@fixture/library')), resolve(f.destination, 'library'));
  assert.equal((await f.run('doctor', { links: { library: 'library' } })).exitCode, 0);
  assert.equal((await f.run('doctor')).exitCode, 1);
});
test('check verifies missing local package links without installing or moving dependencies', async () => {
  const f = fixture('check-links'); f.manifest.repositories.push({ ...f.manifest.repositories[0], id: 'library', repository: 'fixture/library', destination: 'library', dependsOn: [], steps: [] }); f.manifest.repositories[0].dependsOn.push('library'); f.manifest.links = [{ consumer: 'app', provider: 'library', package: '@fixture/library' }];
  await f.run(); const before = snapshot(f.destination); const result = await f.run('check', { links: { library: 'library' } }); assert.equal(result.exitCode, 1); assert.deepEqual(snapshot(f.destination), before); assert.equal(existsSync(resolve(f.destination, 'app/node_modules/@fixture/library')), false);
});
test('path escape, collision, symlink ancestry, missing dependencies and deferred repositories fail', () => {
  const f = fixture('paths');
  for (const destination of ['../escape', '/absolute', 'a/../b', 'a\\b']) { const manifest = structuredClone(f.manifest); manifest.repositories[0].destination = destination; assert.throws(() => validateManifest(manifest, f.destination)); }
  const collision = structuredClone(f.manifest); collision.artifacts[0].destination = 'app/content'; assert.throws(() => validateManifest(collision, f.destination));
  mkdirSync(f.destination, { recursive: true }); symlinkSync(root, resolve(f.destination, 'outside'), 'dir'); const link = structuredClone(f.manifest); link.repositories[0].destination = 'outside/escape'; assert.throws(() => validateManifest(link, f.destination));
  const missing = structuredClone(f.manifest); missing.repositories[0].dependsOn.push('unknown'); assert.throws(() => validateManifest(missing, f.destination));
  for (const repository of ['foss-earth/search', 'foss-earth/vr', '0sfs/vr']) { const deferred = structuredClone(f.manifest); deferred.repositories[0].repository = repository; assert.throws(() => validateManifest(deferred, f.destination)); }
  for (const owner of ['foss-earth', 'UMN-VR']) { const flight = structuredClone(f.manifest); flight.owner = owner; flight.repositories[0].repository = '0sfs/aircraft'; assert.throws(() => validateManifest(flight, f.destination), /flight/); }
  const ssh = structuredClone(f.manifest); ssh.artifacts[0].location = 'ssh://git@example.invalid/artifact'; assert.throws(() => validateManifest(ssh, f.destination), /transport/);
});
test('transport options cannot override exact artifact identity or destinations before mutation', async () => {
  for (const key of ['sha256', 'location', 'sizeBytes', 'destination', 'root', 'fetchImpl']) {
    const f = fixture(`transport-override-${key}`); f.manifest.transport = { maxRedirects: 5, requestTimeoutSeconds: 30, [key]: key === 'sha256' ? '0'.repeat(64) : 'unreviewed-override' };
    assert.throws(() => validateManifest(f.manifest, f.destination), /Transport accepts only/);
    await assert.rejects(f.run(), /Transport accepts only/); assert.equal(existsSync(f.destination), false);
  }
});
test('bootstrap pinned manifest before source checkout; digest/owner failure; Earth/campus without flight', async () => {
  for (const name of ['earth', 'campus', 'flight']) {
    const f = fixture(name); f.manifest.owner = name === 'campus' ? 'UMN-VR' : name === 'flight' ? '0sfs' : 'foss-earth';
    const bytes = Buffer.from(JSON.stringify(f.manifest)), path = resolve(root, `${name}-manifest.json`); writeFileSync(path, bytes);
    const descriptor = { schemaVersion: 1, manifest: { location: pathToFileURL(path).href, sha256: sha256(bytes), sizeBytes: bytes.length, owner: f.manifest.owner, revision: f.manifest.repositories[0].revision } };
    let output = '', bootstrapPlanned = false; const result = await runCli({ args: ['init', '--root', f.destination, '--apply'], bootstrap: descriptor, write: text => { output += text; const event = JSON.parse(text); if (event.event === 'plan' && event.plan[0]?.kind === 'bootstrap-manifest') { assert.equal(existsSync(f.destination), false, 'Bootstrap acquisition plan precedes even the first workspace directory'); bootstrapPlanned = true; } } });
    assert.equal(result.exitCode, 0); assert.equal(bootstrapPlanned, true); assert.ok(output.includes('"event":"plan"')); assert.equal((await runCli({ args: ['doctor', '--root', f.destination], bootstrap: descriptor, write: () => {} })).exitCode, 0);
    assert.equal(result.selection.includes('app'), true); if (name !== 'flight') assert.ok(!JSON.stringify(f.manifest.repositories).includes('0sfs'));
    assert.equal((await runCli({ args: ['init', '--root', `${f.destination}-corrupt`, '--apply'], bootstrap: { ...descriptor, manifest: { ...descriptor.manifest, sha256: '0'.repeat(64) } }, write: () => {} })).exitCode, 2);
  }
});
