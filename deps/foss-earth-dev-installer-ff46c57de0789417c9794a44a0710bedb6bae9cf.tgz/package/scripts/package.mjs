import { mkdirSync, readFileSync, writeFileSync, existsSync, lstatSync } from 'node:fs';
import { spawnSync } from 'node:child_process';
import { resolve } from 'node:path';
import { gzipSync } from 'node:zlib';
import { sha256 } from '../src/manifest.mjs';
import { installArchive } from '../src/archive.mjs';
import { treeDigest } from '../src/archive.mjs';
import { safePath } from '../src/paths.mjs';
const execGit = args => {
  const result = spawnSync('git', ['--no-optional-locks', ...args], { encoding: undefined, maxBuffer: 64 * 1024 * 1024, env: { ...process.env, GIT_NO_REPLACE_OBJECTS: '1' } });
  if (result.status !== 0) throw new Error('Git packaging failed'); return result.stdout;
};
if (execGit(['status', '--porcelain']).toString().trim()) throw new Error('Package only a committed clean candidate');
const revision = execGit(['rev-parse', 'HEAD']).toString().trim();
const tree = execGit(['rev-parse', `${revision}^{tree}`]).toString().trim();
const entries = execGit(['ls-tree', '-r', '-z', revision]).toString().split('\0').filter(Boolean);
const inventory = entries.map(entry => {
  const separator = entry.indexOf('\t'), [mode, type, object] = entry.slice(0, separator).split(' '), path = entry.slice(separator + 1);
  if (type !== 'blob' || !['100644', '100755'].includes(mode)) throw new Error('Installer source archive must contain regular files only');
  const bytes = execGit(['cat-file', 'blob', object]), digest = sha256(bytes);
  if (!lstatSync(path).isFile() || sha256(readFileSync(path)) !== digest) throw new Error(`Working bytes differ from exact source tree: ${path}`);
  return { path, mode, object, sha256: digest, sizeBytes: bytes.length };
});
const identity = JSON.parse(execGit(['show', `${revision}:package.json`]));
if (identity.name !== '@foss-earth/dev-installer' || typeof identity.version !== 'string' || !/^\d+\.\d+\.\d+(?:-[0-9A-Za-z.-]+)?(?:\+[0-9A-Za-z.-]+)?$/.test(identity.version) || !identity.exports?.['./archive'] || !identity.bin || identity.type !== 'module') throw new Error('Package identity/version/public archive export does not match installer contract');
const runtime = inventory.filter(file => file.path === 'package.json' || /^(bin|src|schemas|defaults)\//.test(file.path));
const sealed = new Map(runtime.map(file => [file.path, file]));
const publicEntries = [];
for (const [kind, declarations] of [['bin', identity.bin], ['export', identity.exports]]) {
  if (!declarations || typeof declarations !== 'object' || Array.isArray(declarations)) throw new Error('Public entry declarations must be explicit target maps');
  for (const [name, target] of Object.entries(declarations)) {
    if (typeof target !== 'string' || kind === 'export' && !target.startsWith('./')) throw new Error('Public entries must name exact relative regular files');
    const path = target.startsWith('./') ? target.slice(2) : target;
    safePath(process.cwd(), path);
    if (!sealed.has(path)) throw new Error(`Public target is absent from executable seal: ${name}`);
    publicEntries.push({ kind, name, target, path, sha256: sealed.get(path).sha256 });
  }
}
for (const path of ['LICENSE', 'PROVENANCE.json']) if (!inventory.some(file => file.path === path)) throw new Error('Source archive must retain license and provenance');
const tar = execGit(['archive', '--format=tar', '--prefix=package/', revision]), artifact = gzipSync(tar, { level: 9 });
const folder = safePath(process.cwd(), `build/artifacts/${revision}`), artifactPath = safePath(process.cwd(), `build/artifacts/${revision}/foss-earth-dev-installer-${identity.version}.tgz`); mkdirSync(folder, { recursive: true });
if (existsSync(artifactPath)) { if (!readFileSync(artifactPath).equals(artifact)) throw new Error('Retained archive differs; do not overwrite evidence'); }
else writeFileSync(artifactPath, artifact, { flag: 'wx' });
const fileMap = Object.fromEntries(inventory.map(file => [file.path, file.sha256])), parents = new Set();
for (const file of inventory) { const parts = file.path.split('/'); for (let i = 1; i < parts.length; i++) parents.add(parts.slice(0, i).join('/')); }
const metadataByteBudget = 1024;
const archiveContract = { format: 'tar.gz', destination: `build/artifacts/${revision}/verified-tree`, stripComponents: 1, files: fileMap, treeSha256: treeDigest(fileMap), maxEntries: inventory.length + parents.size + 2, maxExpandedBytes: inventory.reduce((bytes, file) => bytes + file.sizeBytes, 0) + metadataByteBudget, maxTarBytes: tar.length, maxMetadataBytes: metadataByteBudget };
const extracted = await installArchive({ root: process.cwd(), artifactPath, archive: archiveContract });
if (!extracted.valid) throw new Error('Exact archive inventory did not round trip');
const descriptor = { schemaVersion: 1, package: identity.name, version: identity.version, revision, sourceTree: tree, artifactSha256: sha256(artifact), sizeBytes: artifact.length, packageIdentity: { name: identity.name, version: identity.version, type: identity.type, private: identity.private, license: identity.license, engines: identity.engines, bin: identity.bin, exports: identity.exports }, publicEntries, files: Object.fromEntries(runtime.map(file => [file.path, file.sha256])), runtimeFiles: runtime.map(file => file.path), source: { inventorySha256: sha256(JSON.stringify(inventory)), sizeBytes: inventory.reduce((bytes, file) => bytes + file.sizeBytes, 0), files: inventory }, archive: { format: 'tar.gz', prefix: 'package/', tarSha256: sha256(tar), tarSizeBytes: tar.length, files: fileMap, treeSha256: archiveContract.treeSha256, verificationBounds: { maxEntries: archiveContract.maxEntries, maxExpandedBytes: archiveContract.maxExpandedBytes, maxTarBytes: archiveContract.maxTarBytes, maxMetadataBytes: archiveContract.maxMetadataBytes }, verified: true }, earthDefaultBootstrap: inventory.some(file => file.path === 'defaults/earth-bootstrap.json') ? 'defaults/earth-bootstrap.json' : null };
const serialized = JSON.stringify(descriptor, null, 2) + '\n', descriptorPath = resolve(folder, 'release.json');
if (existsSync(descriptorPath)) { if (readFileSync(descriptorPath, 'utf8') !== serialized) throw new Error('Retained descriptor differs; preserve evidence'); }
else writeFileSync(descriptorPath, serialized, { flag: 'wx' });
process.stdout.write(serialized);
