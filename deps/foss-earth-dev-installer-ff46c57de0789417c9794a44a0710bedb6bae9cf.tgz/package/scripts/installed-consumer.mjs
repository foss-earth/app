// Copy this script to a fresh consumer root; all runtime imports resolve there.
import assert from 'node:assert/strict';
import { mkdirSync, writeFileSync, readFileSync, existsSync, readdirSync, lstatSync, realpathSync } from 'node:fs';
import { spawnSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { resolve, dirname } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const consumer = process.cwd(), [releasePath, artifactPath] = process.argv.slice(2);
const release = JSON.parse(readFileSync(releasePath)), hash = bytes => createHash('sha256').update(bytes).digest('hex');
const installed = resolve(consumer, 'node_modules/@foss-earth/dev-installer');
assert.equal(realpathSync(installed), installed); assert.equal(process.env.NODE_PATH ?? '', '');
assert.equal(dirname(dirname(fileURLToPath(import.meta.resolve('@foss-earth/dev-installer')))), installed);
assert.equal(hash(readFileSync(artifactPath)), release.artifactSha256); assert.equal(lstatSync(artifactPath).size, release.sizeBytes);
const identity = JSON.parse(readFileSync(resolve(installed, 'package.json')));
for (const [key, value] of Object.entries(release.packageIdentity)) assert.deepEqual(identity[key], value);
for (const [path, digest] of Object.entries(release.files)) { assert.ok(lstatSync(resolve(installed, path)).isFile()); assert.equal(hash(readFileSync(resolve(installed, path))), digest); }
for (const path of ['LICENSE', 'PROVENANCE.json']) assert.equal(hash(readFileSync(resolve(installed, path))), release.archive.files[path]);
for (const entry of release.publicEntries) assert.equal(release.files[entry.path], entry.sha256);
// Validate every executable byte and package resolution before executing imports.
const { runCli } = await import('@foss-earth/dev-installer');
const { validateManifest, selectComponents } = await import('@foss-earth/dev-installer/manifest');
const { workspace } = await import('@foss-earth/dev-installer/workspace');
const { bootstrapManifest, validateBootstrapDescriptor } = await import('@foss-earth/dev-installer/bootstrap');
const { validateArchive, installArchive, verifyTree, treeDigest } = await import('@foss-earth/dev-installer/archive');
const { verifyPackageIdentity } = await import('@foss-earth/dev-installer/packages');
const { default: schema } = await import('@foss-earth/dev-installer/schema', { with: { type: 'json' } });
assert.ok(schema.$schema); assert.equal(typeof workspace, 'function');
const packageResult = await verifyPackageIdentity({ repo: consumer, identity: { name: release.package, version: release.version, artifact: 'installer', files: release.files } }); assert.equal(packageResult.valid, true);

const scratch = resolve(consumer, 'build/fixtures'); mkdirSync(scratch, { recursive: true });
function git(args, cwd) {
  const environment = Object.fromEntries(Object.entries(process.env).filter(([key]) => !key.startsWith('GIT_')));
  const run = spawnSync('git', ['--no-optional-locks', '-c', 'core.hooksPath=/dev/null', ...args], { cwd, encoding: 'utf8', env: { ...environment, GIT_NO_REPLACE_OBJECTS: '1' } });
  assert.equal(run.status, 0, 'Synthetic fixture Git operation failed'); return run.stdout.trim();
}
const source = resolve(scratch, 'source'); mkdirSync(source);
git(['init', '--quiet', '--initial-branch=main'], source);
writeFileSync(resolve(source, '.gitignore'), '/build/\n/dist/\n');
writeFileSync(resolve(source, 'build.mjs'), 'import {mkdirSync,writeFileSync,readFileSync,existsSync} from "node:fs"; mkdirSync("build",{recursive:true}); mkdirSync("dist",{recursive:true}); const count=existsSync("build/count")?Number(readFileSync("build/count")):0; writeFileSync("build/count",String(count+1)); writeFileSync("dist/receipt.json",JSON.stringify({synthetic:true}));\n');
git(['add', '.gitignore', 'build.mjs'], source); git(['-c', 'user.name=Fixture Human', '-c', 'user.email=fixture@example.invalid', 'commit', '--quiet', '-m', 'Synthetic installed setup fixture'], source);
const revision = git(['rev-parse', 'HEAD'], source), bytes = Buffer.from('Synthetic content only'), content = resolve(scratch, 'content.bin'); writeFileSync(content, bytes);
const ownerReceipts = [];
const quiet = () => {};
function snapshot(root) {
  if (!existsSync(root)) return [];
  const entries = [];
  for (const entry of readdirSync(root, { withFileTypes: true })) { const path = resolve(root, entry.name); if (entry.isDirectory()) entries.push(...snapshot(path)); else entries.push([path, lstatSync(path).mtimeMs, hash(readFileSync(path))]); }
  return entries;
}
for (const owner of ['foss-earth', 'UMN-VR', '0sfs']) {
  const name = owner === 'foss-earth' ? 'earth' : owner === 'UMN-VR' ? 'campus' : 'flight';
  const root = resolve(consumer, `build/workspace ${name}`);
  const manifest = { schemaVersion: 1, id: `synthetic-${name}`, version: '1.0.0', owner,
    repositories: [
      { id: 'library', repository: 'fixture/library', source: pathToFileURL(source).href, revision, destination: 'library', dependsOn: [], steps: [] },
      { id: 'app', repository: 'fixture/app', source: pathToFileURL(source).href, revision, destination: 'app', dependsOn: ['library', 'content'], steps: [{ id: 'build', kind: 'build', argv: ['node', 'build.mjs'], outputs: ['dist/receipt.json'] }, { id: 'check', kind: 'check', argv: ['node', '-e', 'if(!require("node:fs").existsSync("dist/receipt.json"))process.exit(3)'], outputs: [] }] }
    ], artifacts: [{ id: 'content', location: pathToFileURL(content).href, sha256: hash(bytes), sizeBytes: bytes.length, destination: 'artifacts/content.bin' }], defaultComponents: ['app'], selections: { library: ['library'] }, prerequisites: [{ id: 'node', argv: ['node', '--version'], minimumVersion: '22.0.0' }] };
  assert.deepEqual(selectComponents(validateManifest(manifest, root), ['library']).map(item => item.id), ['library']);
  if (owner !== '0sfs') assert.ok(!manifest.repositories.some(item => item.repository.startsWith('0sfs/')));
  const manifestBytes = Buffer.from(JSON.stringify(manifest)), manifestPath = resolve(scratch, `${name}-manifest.json`); writeFileSync(manifestPath, manifestBytes);
  const bootstrap = { schemaVersion: 1, manifest: { location: pathToFileURL(manifestPath).href, sha256: hash(manifestBytes), sizeBytes: manifestBytes.length, revision, owner } }; validateBootstrapDescriptor(bootstrap);
  const bootstrapPath = resolve(scratch, `${name}-bootstrap.json`); writeFileSync(bootstrapPath, JSON.stringify(bootstrap));
  const absentDoctor = await runCli({ args: ['doctor', '--root', root], bootstrap, write: quiet }); assert.equal(absentDoctor.exitCode, 2); assert.equal(existsSync(root), false);
  let bootstrapPlanBeforeWrites = false;
  const first = await runCli({ args: ['init', '--root', root, '--apply'], bootstrap, write: text => { const event = JSON.parse(text); if (event.event === 'plan' && event.plan[0]?.kind === 'bootstrap-manifest') { assert.equal(existsSync(root), false); bootstrapPlanBeforeWrites = true; } } }); assert.equal(first.exitCode, 0); assert.equal(bootstrapPlanBeforeWrites, true); assert.deepEqual(first.selection, ['library', 'content', 'app']);
  const cached = await bootstrapManifest({ descriptor: bootstrap, root, readOnly: true }); assert.equal(cached.digest, hash(manifestBytes));
  const repeat = await runCli({ args: ['init', '--root', root, '--apply'], bootstrap, write: quiet }); assert.equal(repeat.exitCode, 0); assert.ok(repeat.steps.some(step => step.reused)); assert.equal(readFileSync(resolve(root, 'app/build/count'), 'utf8'), '1');
  const before = snapshot(root), doctor = await runCli({ args: ['doctor', '--root', root], bootstrap, write: quiet }); assert.equal(doctor.exitCode, 0); assert.deepEqual(snapshot(root), before);
  assert.equal((await runCli({ args: ['sync', '--root', root, '--apply'], bootstrap, write: quiet })).exitCode, 0);
  assert.equal((await runCli({ args: ['check', '--root', root], bootstrap, write: quiet })).exitCode, 0);
  const selectedRoot = `${root} selected`, selected = await runCli({ args: ['init', '--root', selectedRoot, '--select', 'library', '--apply'], bootstrap, write: quiet }); assert.equal(selected.exitCode, 0); assert.deepEqual(selected.selection, ['library']); assert.equal(existsSync(resolve(selectedRoot, 'app')), false);
  const bin = owner === 'foss-earth' ? 'bin/earth.mjs' : 'bin/workspace.mjs';
  const cli = spawnSync(process.execPath, [resolve(installed, bin), 'doctor', '--bootstrap', bootstrapPath, '--root', root], { cwd: consumer, encoding: 'utf8', env: { ...process.env, NODE_PATH: '' } }); assert.equal(cli.status, 0); assert.equal(JSON.parse(cli.stdout).clean, true);
  writeFileSync(resolve(scratch, `${name}-standalone-doctor.json`), cli.stdout);
  ownerReceipts.push({ owner, syntheticOnly: true, realApplicationQualified: false, noFlightDependency: owner !== '0sfs', bootstrapPlanBeforeWrites, fullDefault: first.selection, selected: selected.selection, first: first.exitCode, repeat: repeat.exitCode, doctor: doctor.exitCode, sync: 0, check: 0, standaloneBin: bin, standaloneDoctor: cli.status, manifestSha256: hash(manifestBytes), revision });
}
const missingDefault = spawnSync(process.execPath, [resolve(installed, 'bin/earth.mjs'), 'init', '--root', resolve(consumer, 'build/missing-default')], { cwd: consumer, encoding: 'utf8', env: { ...process.env, NODE_PATH: '' } }); assert.equal(missingDefault.status, 2); assert.equal(JSON.parse(missingDefault.stdout).issues[0].rule, 'bootstrap.unavailable'); assert.equal(existsSync(resolve(consumer, 'build/missing-default')), false);

const archive = { format: 'tar.gz', destination: 'build/prepared-installer', stripComponents: 1, files: release.archive.files, treeSha256: release.archive.treeSha256, ...release.archive.verificationBounds };
validateArchive(archive, consumer); assert.equal(treeDigest(archive.files), archive.treeSha256);
const firstArchive = await installArchive({ root: consumer, artifactPath, archive }); assert.equal(firstArchive.valid, true); assert.equal(firstArchive.reused, false);
const repeatArchive = await installArchive({ root: consumer, artifactPath, archive, readOnly: true }); assert.equal(repeatArchive.reused, true);
assert.equal((await verifyTree({ root: consumer, archive })).valid, true);
const extra = resolve(consumer, archive.destination, 'unreviewed-directory'); mkdirSync(extra);
assert.equal((await verifyTree({ root: consumer, archive })).valid, false);
await assert.rejects(installArchive({ root: consumer, artifactPath, archive }), error => error.rule === 'archive.conflict'); assert.equal(existsSync(extra), true);
const receipt = { schemaVersion: 1, sourceRevision: release.revision, artifactSha256: release.artifactSha256, sizeBytes: release.sizeBytes, installedRootRegular: true, siblingResolutionDisabled: true, publicExports: Object.keys(identity.exports), publicBins: Object.keys(identity.bin), sealedRuntimeFiles: Object.keys(release.files).length, packageResult, owners: ownerReceipts, archive: { first: firstArchive, repeat: repeatArchive, exactTreeVerified: true, unknownDirectoryRefusedAndPreserved: true }, missingEarthDefaultFailsWithoutWrites: true, platform: { os: process.platform, arch: process.arch, node: process.version }, realApplicationBootstrapQualified: false };
writeFileSync(resolve(consumer, 'installed-receipt.json'), JSON.stringify(receipt, null, 2) + '\n', { flag: 'wx' });
process.stdout.write(JSON.stringify(receipt, null, 2) + '\n');
