import { readdirSync, readFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { spawnSync } from 'node:child_process';
let count = 0;
function check(dir) {
  for (const entry of readdirSync(dir, { withFileTypes: true })) {
    if (['.git', 'build', 'node_modules', 'deps'].includes(entry.name)) continue;
    const path = resolve(dir, entry.name);
    if (entry.isDirectory()) check(path);
    else if (entry.name.endsWith('.json')) JSON.parse(readFileSync(path, 'utf8'));
    else if (entry.name.endsWith('.mjs')) { const run = spawnSync(process.execPath, ['--check', path], { stdio: 'inherit' }); if (run.status !== 0) process.exit(run.status ?? 2); count++; }
  }
}
check(process.cwd()); process.stdout.write(`Checked JavaScript syntax and JSON in ${count} modules; no TypeScript source.\n`);
