# Shared developer setup

`@foss-earth/dev-installer` owns generic workspace-manifest/bootstrap handling,
safe checkout/install/build/check orchestration and read-only diagnostics.
Applications own their compatible manifests. Flight/campus wrappers call the
public API with a pinned data descriptor; no application runtime is imported.

YOU CANNOT HAVE AI AS A CO-AUTHOR, OR YOUR CONTRIBUTIONS WILL BE REJECTED.

```sh
foss-earth-workspace init --manifest workspace.json --root "workspace path"
foss-earth-workspace init --bootstrap reviewed-bootstrap.json --root "workspace path" --apply
foss-earth-workspace doctor --manifest workspace.json --root "workspace path"
foss-earth-workspace sync --manifest next-workspace.json --root "workspace path" --apply
foss-earth-workspace check --manifest workspace.json --root "workspace path" --select library
```

Init/sync preview without `--apply`; mutation is explicit. The declared full
default workspace is the default. `--select` accepts a component or named
selection and includes dependency closure. Fetch/install/build actions are
emitted before they run. `doctor` does not fetch, install, create directories,
change the Git index or write journals/logs; remote freshness is unknown offline.
`check` runs declared checks and retains results without cloning/installing.

Exact Git revisions and artifact SHA-256/byte sizes are required. Existing dirty,
diverged, incompatible-source or conflicting destinations stop with repair
advice. Sync only moves a clean source forward to the explicit pin; local commits
and evidence are retained. No reset, clean, stash or deletion. Failed staging,
downloads, commands and incomplete journals remain under workspace/build/.
Success is reused only when the complete input fingerprint and declared output
digests still match; checks always run. Steps without output receipts rerun.

Development links require explicit `--links` JSON. Source identity must still
match the manifest. Links are installed before consumer builds and diagnosed
by doctor. Existing installed package directories are moved into retained
build/link-backups evidence; unrelated/wrong development links fail. Exact mode
uses pinned artifacts/source and never mutable neighboring checkouts.

No global/system tool installer, server/watch startup or implicit native/WASM
build runs. Known native commands require a named opt-in. Trusted application
manifests must classify their build scripts honestly. Default flight setup uses
its accepted JSBSim artifact; flight wrapper owns the explicit native path.
No Search or shared/flight VR component is allowed in current manifests.

`foss-earth-setup` is the standalone Earth entry and accepts the same explicit
manifest/bootstrap inputs. Its default descriptor is an Earth-owned pure-data
artifact installed at defaults/earth-bootstrap.json. Until the Earth primary
supplies an accepted descriptor/artifact set, default setup fails with an
actionable missing-input result rather than inventing compatible packages.
Full Earth/campus fixture workspaces contain no flight dependency. Real app
bootstrap receipts remain pending their accepted artifacts.

See [manifest and wrapper contract](docs/contracts.md), [safe operations](docs/operations.md)
and [acceptance](docs/acceptance.md). Version 0.1.0 is private staging; no registry
publication or untested OS support is claimed. Node 22+ and Git are required.
