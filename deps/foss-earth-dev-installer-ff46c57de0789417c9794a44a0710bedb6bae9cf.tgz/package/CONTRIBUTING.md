# Contributing

YOU CANNOT HAVE AI AS A CO-AUTHOR, OR YOUR CONTRIBUTIONS WILL BE REJECTED.

AI author/committer and identity-bearing trailers are also prohibited. Preserve
human credit, upstream/asset rights and existing evidence. Use the installed
pinned common @foss-earth/ci validator and its shared consumer-conformance command;
do not copy their implementation or put synthetic invalid commits in real history.

Owner checks are npm run typecheck, npm run lint and affected Node test files;
finish with npm run ci once. Reserve the shared slot first, one test worker,
and retain output under build/. JavaScript syntax/JSON checks are not TypeScript
type analysis. No server, benchmark, native/WASM build or tool installation is
implicit. Package only a committed clean candidate with exact provenance.
